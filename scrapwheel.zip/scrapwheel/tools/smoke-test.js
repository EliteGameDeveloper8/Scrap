/*
 * Smoke test: opens the game in a headless browser, plays through the main systems and checks them.
 *   npm install && npx playwright install chromium
 *   npm test                      (set CHROME_PATH to use an installed Chrome instead)
 * Screenshots are saved in test-output/.
 */
const path = require('path');
const fs = require('fs');
const { chromium } = require('playwright');

const ROOT = path.resolve(__dirname, '..');
const OUT = path.join(ROOT, 'test-output');
const failures = [];

function check(name, ok, detail) {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}${detail !== undefined ? '  (' + detail + ')' : ''}`);
  if (!ok) failures.push(name);
}

// Drives the current run with a simple autopilot (full throttle, keep level) for up to `seconds`.
const autopilot = seconds =>
  `(() => {
    let t = 0;
    const r = SW.Run.current();
    while (r.status !== 'over' && t < ${seconds}) {
      const a = r.v.main.getAngle(), w = r.v.main.getAngularVelocity();
      const lean = -a * 3 - w * 0.8;
      SW.Run.update(1 / 60, { throttle: 1, lean: Math.abs(lean) > 0.2 ? Math.sign(lean) : 0, boost: false });
      t += 1 / 60;
    }
    return { status: r.status, time: r.time, x: r.v.main.getPosition().x };
  })()`;

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || undefined });
  const page = await browser.newPage({ viewport: { width: 1280, height: 760 } });
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => m.type() === 'error' && errors.push(m.text()));
  const shot = name => page.screenshot({ path: path.join(OUT, name + '.png') });

  await page.goto('file://' + path.join(ROOT, 'index.html'));
  await page.waitForFunction(() => document.body.classList.contains('ready'));
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.waitForFunction(() => document.body.classList.contains('ready'));
  await page.waitForTimeout(400);
  await shot('01-title');

  // ---- missions and garage ----
  await page.click('#s-title [data-go=missions]');
  const missions = await page.evaluate(() => ({
    total: document.querySelectorAll('.mission').length,
    locked: document.querySelectorAll('.mission.locked').length,
  }));
  check(
    'missions are listed, later ones locked',
    missions.total >= 10 && missions.locked >= 8,
    JSON.stringify(missions),
  );
  await shot('02-missions');
  await page.click('[data-act=mission][data-arg=first]');
  await page.waitForTimeout(300);
  await shot('03-garage');

  const cellXY = (c, r) =>
    page.evaluate(
      ([c, r]) => {
        const grid = document.getElementById('grid');
        const rect = grid.getBoundingClientRect();
        // find the grid's cell size by probing the garage layout (same formula as SW.Garage.layout)
        const w = grid.clientWidth;
        const h = grid.clientHeight;
        const cell = Math.floor(Math.min((w - 16) / SW.CFG.COLS, (h - 16) / (SW.CFG.ROWS + 0.6)));
        const ox = Math.floor((w - cell * SW.CFG.COLS) / 2);
        const oy = Math.floor((h - cell * SW.CFG.ROWS) / 2 + cell * 0.3);
        return [rect.left + ox + (c + 0.5) * cell, rect.top + oy + (r + 0.5) * cell];
      },
      [c, r],
    );
  const count = () => page.evaluate(() => SW.Garage.blueprint().cells.length);
  const before = await count();
  await page.click('.part-btn[data-part=wood]');
  let [x, y] = await cellXY(7, 5);
  await page.mouse.click(x, y);
  check('clicking the grid places a part', (await count()) === before + 1);
  await page.mouse.click(x, y, { button: 'right' });
  check('right-click removes a part', (await count()) === before);
  await page.keyboard.press('Control+z');
  check('undo brings it back', (await count()) === before + 1);
  [x, y] = await cellXY(1, 1);
  await page.mouse.click(x, y);
  const loose = await page.evaluate(
    () => document.querySelector('#g-warnings .err') !== null && document.getElementById('g-drive').disabled,
  );
  check('a loose part blocks driving', loose);
  await page.evaluate(() => {
    const bp = SW.Garage.blueprint();
    bp.cells = bp.cells.filter(c => !(c[0] === 1 && c[1] === 1) && !(c[0] === 7 && c[1] === 5));
    SW.Garage.setBlueprint(bp);
  });
  const stats = await page.evaluate(() => document.getElementById('g-stats').textContent);
  check('stats are shown', /Mass/.test(stats) && /Top speed/.test(stats));

  // ---- my builds: save, share code, import ----
  await page.click('[data-modal=builds]');
  await page.fill('#build-name', 'Test <b>rig</b>');
  await page.click('[data-act=save-build]');
  const saved = await page.evaluate(() => ({
    n: SW.Save.builds().length,
    html: document.querySelector('.build-row b').innerHTML,
  }));
  check('build saves, name escaped', saved.n === 1 && saved.html.includes('&lt;b&gt;'), saved.html);
  await page.click('[data-act=code-build]');
  const code = await page.inputValue('#build-code');
  check('share code is made', code.startsWith('SW1:'));
  await page.fill('#build-code', 'nonsense');
  await page.click('[data-act=import-build]');
  check('bad share code is rejected', (await page.textContent('#build-error')).length > 5);
  await page.fill('#build-code', code);
  await page.click('[data-act=import-build]');
  check('share code imports', (await page.evaluate(() => SW.UI.modal())) === null);

  // ---- drive the first mission ----
  await page.click('#g-drive');
  await page.waitForTimeout(300);
  await page.keyboard.down('KeyD');
  await page.waitForTimeout(1500);
  await page.keyboard.up('KeyD');
  const moving = await page.evaluate(() => SW.Run.current().v.main.getPosition().x);
  check('keyboard drives the vehicle', moving > 7, moving.toFixed(1));
  await shot('04-drive');
  const run = await page.evaluate(autopilot(60));
  await page.waitForTimeout(1500);
  const result = await page.evaluate(() => ({
    modal: SW.UI.modal(),
    title: document.querySelector('#modal-card h2') && document.querySelector('#modal-card h2').textContent,
    prof: SW.Save.profile(),
  }));
  check(
    'first mission can be finished',
    result.modal === 'result' && /Finished/.test(result.title),
    JSON.stringify(run),
  );
  check(
    'progress, coins and reward parts are saved',
    result.prof.missions.first &&
      result.prof.missions.first.done &&
      result.prof.coins > 100 &&
      result.prof.inventory.wood === 16,
  );
  await shot('05-result');

  // ---- crash: driver's head ----
  await page.click('#modal [data-act=restart]');
  await page.waitForTimeout(200);
  const crash = await page.evaluate(() => {
    const r = SW.Run.current();
    r.v.main.setAngle(Math.PI);
    r.v.main.setPosition(planck.Vec2(r.v.main.getPosition().x, r.v.main.getPosition().y + 1));
    for (let i = 0; i < 240 && r.status !== 'over'; i++) SW.Run.update(1 / 60, { throttle: 0, lean: 0, boost: false });
    return SW.UI.modal() + ' ' + document.querySelector('#modal-card h2').textContent;
  });
  check('landing upside down ends the run', /result .*head/.test(crash), crash);

  // ---- every mission can be reached from the list once unlocked ----
  await page.click('#modal [data-act=to-garage]');
  const next = await page.evaluate(() => {
    SW.UI.go('missions');
    return !document.querySelector('[data-arg=hills]').disabled;
  });
  check('finishing unlocks the next mission', next);

  // ---- shop ----
  await page.evaluate(() => SW.UI.go('shop'));
  const coins0 = await page.evaluate(() => SW.Save.profile().coins);
  await page.click('[data-act=buy][data-arg=wood]');
  const bought = await page.evaluate(() => ({
    coins: SW.Save.profile().coins,
    wood: SW.Save.profile().inventory.wood,
  }));
  check('shop sells parts', bought.coins === coins0 - 15 && bought.wood === 17, JSON.stringify(bought));
  await shot('06-shop');

  // ---- the test track and a delivery ----
  const test = await page.evaluate(() => {
    SW.Game.drive(SW.CFG.TEST);
    return !!SW.Run.current();
  });
  check('test track starts', test);
  const delivery = await page.evaluate(() => {
    const bp = {
      name: 'hauler',
      susp: 'soft',
      cells: [
        [4, 6, 'wood', 0],
        [5, 6, 'seat', 0],
        [6, 6, 'engine', 0],
        [7, 6, 'tank', 0],
        [8, 6, 'bed', 0],
        [9, 6, 'bed', 0],
        [10, 6, 'wood', 0],
        [7, 5, 'wood', 0],
        [10, 5, 'wood', 0],
        [4, 7, 'wheel', 0],
        [10, 7, 'wheel', 0],
      ],
    };
    SW.Save.profile().inventory.bed = 2;
    SW.Garage.setBlueprint(bp);
    SW.Game.drive(SW.CFG.MISSIONS.find(m => m.id === 'delivery'));
    const r = SW.Run.current();
    return !!r.crate;
  });
  check('delivery loads a crate onto the bed', delivery);
  await page.waitForTimeout(400);
  await shot('07-delivery');

  // ---- saved on the device ----
  await page.reload();
  await page.waitForFunction(() => document.body.classList.contains('ready'));
  const kept = await page.evaluate(() => ({
    done: !!SW.Save.profile().missions.first,
    builds: SW.Save.builds().length,
  }));
  check('progress and builds survive a reload', kept.done && kept.builds === 1, JSON.stringify(kept));

  // ---- phone layout ----
  await page.setViewportSize({ width: 390, height: 780 });
  await page.evaluate(() => SW.UI.go('garage'));
  await page.waitForTimeout(300);
  await shot('08-phone-garage');
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > innerWidth);
  check('no horizontal overflow on a phone', !overflow);

  check('no errors in the page', errors.length === 0, errors.slice(0, 3).join(' | '));
  await browser.close();
  console.log(failures.length ? `\n${failures.length} check(s) failed.` : '\nAll checks passed.');
  process.exit(failures.length ? 1 : 0);
})();
