/*
 * Sound, synthesised with the Web Audio API (no sound files): an engine hum that follows the
 * throttle and wheel speed, a rocket roar while boosting, and short effects for coins, fuel,
 * breaking parts, crashes and wins. Starts on the first key press or tap (browser rule).
 */
'use strict';

SW.Audio = (() => {
  let ac = null;
  let master = null;
  let engine = null;
  let boost = null;
  let noiseBuffer = null;

  function ensure() {
    if (ac || !SW.Save.settings().sound) return ac;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return null;
    ac = new Ctx();
    master = ac.createGain();
    master.gain.value = 0.5;
    master.connect(ac.destination);
    noiseBuffer = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
    const data = noiseBuffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;

    const osc = ac.createOscillator();
    osc.type = 'sawtooth';
    const lp = ac.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 400;
    const g = ac.createGain();
    g.gain.value = 0;
    osc.connect(lp).connect(g).connect(master);
    osc.start();
    engine = { osc, lp, g };

    const src = ac.createBufferSource();
    src.buffer = noiseBuffer;
    src.loop = true;
    const bp = ac.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = 700;
    const bg = ac.createGain();
    bg.gain.value = 0;
    src.connect(bp).connect(bg).connect(master);
    src.start();
    boost = { g: bg };
    return ac;
  }

  function unlock() {
    ensure();
    if (ac && ac.state === 'suspended') ac.resume();
  }

  // Called every frame while driving (pass null to silence).
  function drive(v) {
    if (!ac || !engine) return;
    const on = SW.Save.settings().sound && v;
    const now = ac.currentTime;
    const speed = on ? Math.abs(v.main.getLinearVelocity().x) : 0;
    const throttle = on ? Math.abs(v.throttle) : 0;
    const power = on ? v.stats.power : 0;
    engine.osc.frequency.setTargetAtTime(power ? 45 + speed * 7 + throttle * 25 : 40, now, 0.08);
    engine.lp.frequency.setTargetAtTime(300 + throttle * 700, now, 0.1);
    engine.g.gain.setTargetAtTime(power && on ? 0.05 + throttle * 0.1 : 0, now, 0.1);
    boost.g.gain.setTargetAtTime(on && v.boosting ? 0.25 : 0, now, 0.05);
  }

  function tone(freq, start, dur, type, vol) {
    const o = ac.createOscillator();
    const g = ac.createGain();
    o.type = type || 'sine';
    o.frequency.value = freq;
    g.gain.setValueAtTime(vol || 0.2, start);
    g.gain.exponentialRampToValueAtTime(0.001, start + dur);
    o.connect(g).connect(master);
    o.start(start);
    o.stop(start + dur);
  }

  function noise(start, dur, freq, vol) {
    const src = ac.createBufferSource();
    src.buffer = noiseBuffer;
    const f = ac.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = freq;
    const g = ac.createGain();
    g.gain.setValueAtTime(vol, start);
    g.gain.exponentialRampToValueAtTime(0.001, start + dur);
    src.connect(f).connect(g).connect(master);
    src.start(start);
    src.stop(start + dur);
  }

  function play(name) {
    if (!SW.Save.settings().sound || !ensure()) return;
    const t = ac.currentTime;
    if (name === 'coin') {
      tone(988, t, 0.08, 'square', 0.06);
      tone(1319, t + 0.07, 0.18, 'square', 0.06);
    } else if (name === 'fuel') {
      tone(440, t, 0.1, 'triangle', 0.15);
      tone(660, t + 0.1, 0.2, 'triangle', 0.15);
    } else if (name === 'break') noise(t, 0.25, 2200, 0.35);
    else if (name === 'crash') {
      noise(t, 0.6, 500, 0.6);
      tone(90, t, 0.4, 'sine', 0.3);
    } else if (name === 'win') [523, 659, 784, 1047].forEach((f, i) => tone(f, t + i * 0.11, 0.25, 'triangle', 0.18));
    else if (name === 'click') tone(660, t, 0.05, 'square', 0.04);
  }

  function setEnabled(on) {
    if (!on && master) master.gain.value = 0;
    if (on) {
      ensure();
      if (master) master.gain.value = 0.5;
    }
  }

  return { unlock, drive, play, setEnabled };
})();
