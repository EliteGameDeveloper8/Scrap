/*
 * The driving HUD: fuel gauge, progress along the course, time and coins, plus a hint
 * when the vehicle seems stuck.
 */
'use strict';

SW.HUD = (() => {
  const $ = SW.util.$;
  let still = 0;
  let lastX = 0;

  function show(on) {
    $('hud').classList.toggle('hidden', !on);
    still = 0;
    lastX = 0;
    hint('');
  }

  function hint(text) {
    const el = $('h-hint');
    el.textContent = text;
    el.classList.toggle('hidden', !text);
  }

  function update(run, dt) {
    if (!run) return;
    const v = run.v;
    const fuel = v.fuelMax ? v.fuel / v.fuelMax : 0;
    const gauge = $('h-fuel');
    gauge.style.width = Math.round(fuel * 100) + '%';
    gauge.className = fuel < 0.2 ? 'low' : '';
    const x = v.main.getPosition().x;
    const t = run.track;
    const goal = t.finish !== null ? t.finish : t.end - 42;
    const done = SW.util.clamp((x - t.start) / (goal - t.start), 0, 1);
    $('h-progress').style.width = done * 100 + '%';
    $('h-car').style.left = done * 100 + '%';
    $('h-dist').textContent = Math.max(0, Math.round(goal - x)) + ' m to go';
    $('h-time').textContent = SW.util.time(run.time);
    $('h-coins').textContent = run.coins;

    if (run.status !== 'driving') return hint('');
    // stuck: no new ground covered for a while
    still = run.maxX > lastX + 0.05 ? 0 : still + dt;
    lastX = Math.max(lastX, run.maxX);
    if (still > 6) hint('Stuck? Press R to restart, or Esc to go back to the garage.');
    else if (v.fuel <= 0) hint('Out of fuel!');
    else hint('');
  }

  return { show, update };
})();
