/*
 * Driving controls from the keyboard and the on-screen touch buttons.
 *   D / →  accelerate       A / ←  brake and reverse
 *   W / ↑  tilt back        S / ↓  tilt forward
 *   Space  rocket boost     R      restart        Esc   pause
 * SW.Input.state() returns { throttle -1..1, lean -1..1, boost }.
 */
'use strict';

SW.Input = (() => {
  const keys = new Set();
  const touch = new Set();

  function init() {
    addEventListener('keydown', e => {
      SW.Audio.unlock();
      if (e.target.matches && e.target.matches('input, textarea')) return;
      keys.add(e.code);
      SW.Game.key(e);
    });
    addEventListener('keyup', e => keys.delete(e.code));
    addEventListener('blur', () => {
      keys.clear();
      touch.clear();
    });
    addEventListener('pointerdown', () => SW.Audio.unlock(), { passive: true });

    for (const b of document.querySelectorAll('[data-touch]')) {
      const name = b.dataset.touch;
      const on = e => {
        e.preventDefault();
        touch.add(name);
        b.classList.add('down');
      };
      const off = () => {
        touch.delete(name);
        b.classList.remove('down');
      };
      b.addEventListener('pointerdown', on);
      b.addEventListener('pointerup', off);
      b.addEventListener('pointercancel', off);
      b.addEventListener('pointerleave', off);
    }
    if (matchMedia('(pointer: coarse)').matches) document.body.classList.add('touch-device');
  }

  const down = (...codes) => codes.some(c => keys.has(c));

  function state() {
    const fwd = down('KeyD', 'ArrowRight') || touch.has('gas');
    const back = down('KeyA', 'ArrowLeft') || touch.has('reverse');
    const tiltB = down('KeyW', 'ArrowUp') || touch.has('leanB');
    const tiltF = down('KeyS', 'ArrowDown') || touch.has('leanF');
    return {
      throttle: (fwd ? 1 : 0) - (back ? 1 : 0),
      lean: (tiltB ? 1 : 0) - (tiltF ? 1 : 0),
      boost: down('Space') || touch.has('boost'),
      brake: false,
    };
  }

  const clear = () => {
    keys.clear();
    touch.clear();
  };

  return { init, state, clear };
})();
