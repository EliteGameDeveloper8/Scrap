/*
 * Screens and windows outside the drive:
 *   title, missions (pick one, see stars and rewards), shop (buy parts with coins), settings
 *   modal windows: my builds (save, load, delete, share codes), drive results, pause
 *   confirm() for anything that can't be undone, toast() for short messages
 * Buttons use data-go="screen", data-modal="name" or data-act="action".
 * Build names typed by the player are escaped before they are shown.
 */
'use strict';

SW.UI = (() => {
  const C = SW.CFG;
  const U = SW.util;
  const $ = U.$;
  const esc = U.esc;
  let screen = 'title';
  let previous = 'title';
  let modal = null;
  let confirmResolve = null;

  function init() {
    document.body.addEventListener('click', e => {
      const b = e.target.closest('[data-go], [data-modal], [data-act]');
      if (!b || b.disabled) return;
      SW.Audio.play('click');
      if (b.dataset.go) go(b.dataset.go === 'back' ? previous : b.dataset.go);
      else if (b.dataset.modal) openModal(b.dataset.modal);
      else act(b.dataset.act, b.dataset.arg, b);
    });
    $('modal').addEventListener('click', e => {
      if (e.target.id === 'modal' && modal !== 'result') closeModal();
    });
    for (const el of document.querySelectorAll('[data-setting]')) {
      el.addEventListener('change', () => {
        SW.Save.setSetting(el.dataset.setting, el.checked);
        if (el.dataset.setting === 'sound') SW.Audio.setEnabled(el.checked);
      });
    }
    $('confirm-ok').addEventListener('click', () => closeConfirm(true));
    $('confirm-cancel').addEventListener('click', () => closeConfirm(false));
  }

  // ---- screens ----

  function go(name, arg) {
    if (name !== screen && screen !== 'drive') previous = screen;
    if (name === 'garage' && arg === undefined) arg = SW.Garage.mission();
    screen = name;
    closeModal();
    for (const s of document.querySelectorAll('.screen')) s.classList.toggle('active', s.id === 's-' + name);
    SW.HUD.show(name === 'drive');
    document.body.dataset.screen = name;
    for (const el of document.querySelectorAll('.coins')) el.textContent = SW.Save.profile().coins;
    if (name === 'missions') missions();
    if (name === 'shop') shop();
    if (name === 'garage') SW.Garage.open(arg || null);
    if (name === 'settings') {
      for (const el of document.querySelectorAll('[data-setting]'))
        el.checked = !!SW.Save.settings()[el.dataset.setting];
    }
  }

  function missions() {
    const prof = SW.Save.profile();
    const list = C.MISSIONS.map((m, i) => {
      const rec = prof.missions[m.id] || { stars: [false, false, false] };
      const locked = i > 0 && !(prof.missions[C.MISSIONS[i - 1].id] || {}).done;
      const stars = rec.stars.map(s => `<span class="${s ? 'on' : ''}">★</span>`).join('');
      const tags = [m.goal === 'deliver' ? 'Cargo' : '', m.gravity ? 'Low gravity' : '', m.fuelScale ? 'Low fuel' : '']
        .filter(Boolean)
        .map(t => `<em>${t}</em>`)
        .join('');
      return `<button class="mission ${locked ? 'locked' : ''}" ${locked ? 'disabled' : ''} data-act="mission" data-arg="${m.id}">
        <span class="num">${i + 1}</span>
        <b>${esc(m.name)}</b>
        <span class="desc">${locked ? 'Finish the previous mission to unlock.' : esc(m.desc)}</span>
        <span class="tags">${tags}</span>
        <span class="stars">${stars}</span>
        ${rec.best ? `<span class="best">Best ${U.time(rec.best)}</span>` : ''}
      </button>`;
    });
    list.push(`<button class="mission test" data-act="mission" data-arg="test">
      <span class="num">∞</span><b>Test track</b><span class="desc">${esc(C.TEST.desc)} Unlimited fuel.</span><span class="tags"></span></button>`);
    $('mission-list').innerHTML = list.join('');
  }

  function shop() {
    const prof = SW.Save.profile();
    $('shop-list').innerHTML = '';
    for (const [id, P] of Object.entries(C.PARTS)) {
      if (!P.price) continue;
      const card = document.createElement('div');
      card.className = 'shop-item';
      card.appendChild(SW.Draw.icon(id, 30));
      const info = document.createElement('div');
      info.innerHTML = `<b>${esc(P.name)}</b><p>${esc(P.desc)}</p><small>You own ${prof.inventory[id] || 0}</small>`;
      card.appendChild(info);
      const buy = document.createElement('button');
      buy.className = 'btn primary small';
      buy.dataset.act = 'buy';
      buy.dataset.arg = id;
      buy.disabled = prof.coins < P.price;
      buy.innerHTML = `Buy · <span class="coin"></span>${P.price}`;
      card.appendChild(buy);
      $('shop-list').appendChild(card);
    }
  }

  // ---- actions ----

  async function act(name, arg) {
    const prof = SW.Save.profile();
    if (name === 'mission') {
      const m = arg === 'test' ? C.TEST : C.MISSIONS.find(x => x.id === arg);
      if (m) go('garage', m.test ? null : m);
      if (m && m.test) SW.Game.drive(C.TEST);
    }
    if (name === 'buy') {
      const P = C.PARTS[arg];
      if (prof.coins < P.price) return;
      prof.coins -= P.price;
      prof.inventory[arg] = (prof.inventory[arg] || 0) + 1;
      SW.Save.saveProfile();
      toast(`Bought a ${P.name.toLowerCase()}.`);
      go('shop');
    }
    if (
      name === 'reset' &&
      (await confirm('Delete all coins, parts and mission progress? Saved builds are kept.', 'Reset progress', true))
    ) {
      SW.Save.resetProfile();
      toast('Progress reset.');
      go('title');
    }
    if (name === 'close-modal') closeModal();
    if (name === 'drive' && SW.Garage.mission()) SW.Game.drive(SW.Garage.mission());
    if (name === 'test') SW.Game.drive(C.TEST);
    if (name === 'restart') SW.Game.restart();
    if (name === 'pause') SW.Game.pause(true);
    if (name === 'resume') SW.Game.pause(false);
    if (name === 'to-garage') SW.Game.toGarage();
    if (name === 'next') {
      const i = C.MISSIONS.findIndex(m => m.id === arg);
      go('garage', C.MISSIONS[i + 1]);
    }
    if (name === 'save-build') {
      const entry = SW.Save.storeBuild(SW.Garage.blueprint(), $('build-name').value);
      if (entry) toast(`Saved “${entry.name}”.`);
      builds();
    }
    if (name === 'load-build') {
      const b = SW.Save.builds().find(x => x.id === arg);
      if (b) {
        SW.Garage.setBlueprint(SW.Blueprint.sanitize(b));
        closeModal();
        toast(`Loaded “${b.name}”.`);
      }
    }
    if (name === 'delete-build') {
      const b = SW.Save.builds().find(x => x.id === arg);
      if (b && (await confirm(`Delete the build “${b.name}”?`, 'Delete build', true))) {
        SW.Save.removeBuild(arg);
        builds();
      }
    }
    if (name === 'code-build') {
      const b = SW.Save.builds().find(x => x.id === arg);
      if (b) {
        $('build-code').value = SW.Save.exportCode(b);
        $('build-code').select();
      }
    }
    if (name === 'import-build') {
      try {
        const bp = SW.Save.importCode($('build-code').value);
        SW.Garage.setBlueprint(bp);
        closeModal();
        toast('Build imported. Parts you do not own yet are listed in the garage.');
      } catch (err) {
        $('build-error').textContent = err.message;
      }
    }
  }

  // ---- modals ----

  function openModal(name, data) {
    modal = name;
    $('modal').classList.remove('hidden');
    if (name === 'builds') builds();
    if (name === 'result') result(data);
    if (name === 'pause') {
      $('modal-card').className = 'modal-card small';
      $('modal-card').innerHTML = `<h2>Paused</h2><div class="stack">
        <button class="btn primary" data-act="resume">Resume</button>
        <button class="btn" data-act="restart">Restart</button>
        <button class="btn" data-act="to-garage">Back to the garage</button></div>`;
    }
  }

  function closeModal() {
    modal = null;
    $('modal').classList.add('hidden');
    $('modal-card').innerHTML = '';
  }

  function builds() {
    const bp = SW.Garage.blueprint();
    const list = SW.Save.builds();
    const rows = list.length
      ? list
          .map(
            b => `<div class="build-row"><div><b>${esc(b.name)}</b><small>${b.cells.length} parts · ${new Date(b.updated).toLocaleDateString()}</small></div>
          <div class="row-btns"><button class="btn small primary" data-act="load-build" data-arg="${esc(b.id)}">Load</button>
          <button class="btn small ghost" data-act="code-build" data-arg="${esc(b.id)}" title="Show a code you can share">Share code</button>
          <button class="btn small ghost danger-text" data-act="delete-build" data-arg="${esc(b.id)}">Delete</button></div></div>`,
          )
          .join('')
      : '<p class="muted">No saved builds yet.</p>';
    $('modal-card').className = 'modal-card';
    $('modal-card').innerHTML =
      `<header class="m-head"><h2>My builds</h2><button class="icon-btn" data-act="close-modal" aria-label="Close">×</button></header>
      <label class="field"><span>Save the bench as</span><span class="inline">
        <input id="build-name" maxlength="30" value="${esc(bp.name || 'My vehicle')}"><button class="btn primary" data-act="save-build">Save</button></span></label>
      <div class="build-list">${rows}</div>
      <label class="field"><span>Share code</span><textarea id="build-code" rows="2" placeholder="Paste a build code here to import it"></textarea></label>
      <p id="build-error" class="error"></p>
      <button class="btn" data-act="import-build">Import code</button>`;
  }

  function result(r) {
    const m = r.mission;
    let html;
    if (r.win) {
      const labels = [
        m.goal === 'deliver' ? 'Delivered' : 'Finished',
        `Within ${U.time(m.par)}`,
        `${m.parts} parts or fewer`,
      ];
      const stars = r.stars
        .map((s, i) => `<li class="${s ? 'on' : ''}"><span class="star">★</span>${labels[i]}</li>`)
        .join('');
      const reward = r.reward
        ? `<div class="reward"><span>New parts:</span>${Object.entries(r.reward)
            .map(([p, n]) => `<em>${n}× ${esc(C.PARTS[p].name)}</em>`)
            .join('')}</div>`
        : '';
      const i = C.MISSIONS.indexOf(m);
      html = `<h2 class="win">${m.goal === 'deliver' ? 'Delivered!' : 'Finished!'}</h2>
        <ul class="star-list">${stars}</ul>
        <div class="result-stats"><div><span>Time</span><b>${U.time(r.time)}</b></div><div><span>Best</span><b>${U.time(r.best)}</b></div>
        <div><span>Coins</span><b>+${r.earned}</b></div></div>${reward}
        <div class="row-btns">
          <button class="btn" data-act="restart">Retry</button>
          <button class="btn" data-act="to-garage">Garage</button>
          ${C.MISSIONS[i + 1] ? `<button class="btn primary" data-act="next" data-arg="${m.id}">Next mission</button>` : ''}
        </div>`;
    } else {
      html = `<h2 class="${r.neutral ? '' : 'lose'}">${esc(r.reason)}</h2><p class="hint">${esc(r.hint || '')}</p>
        <div class="result-stats"><div><span>Time</span><b>${U.time(r.time)}</b></div><div><span>Distance</span><b>${Math.round(r.distance)} m</b></div></div>
        <div class="row-btns"><button class="btn" data-act="to-garage">Garage</button><button class="btn primary" data-act="restart">Retry</button></div>`;
    }
    $('modal-card').className = 'modal-card small result';
    $('modal-card').innerHTML = html;
  }

  // ---- confirm and toasts ----

  function confirm(text, okLabel, danger) {
    closeConfirm(false);
    $('confirm-text').textContent = text;
    const ok = $('confirm-ok');
    ok.textContent = okLabel;
    ok.className = 'btn ' + (danger ? 'danger' : 'primary');
    $('confirm').classList.remove('hidden');
    ok.focus();
    return new Promise(res => (confirmResolve = res));
  }

  function closeConfirm(v) {
    $('confirm').classList.add('hidden');
    if (confirmResolve) {
      const r = confirmResolve;
      confirmResolve = null;
      r(v);
    }
  }

  function toast(text) {
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = text;
    $('toasts').prepend(el);
    while ($('toasts').children.length > 3) $('toasts').lastChild.remove();
    setTimeout(() => el.classList.add('out'), 2600);
    setTimeout(() => el.remove(), 3000);
  }

  // Esc: closes the top window. Returns true if something was closed.
  function back() {
    if (confirmResolve) {
      closeConfirm(false);
      return true;
    }
    if (modal && modal !== 'result' && modal !== 'pause') {
      closeModal();
      return true;
    }
    return false;
  }

  return { init, go, openModal, closeModal, confirm, toast, back, screen: () => screen, modal: () => modal };
})();
