/*
 * Game flow and the frame loop.
 *   SW.Game.drive(mission)   check the bench design and start driving
 *   SW.Game.restart()        drive the same mission again
 *   SW.Game.toGarage()       leave the drive for the garage
 *   SW.Game.runEnded(result) called by SW.Run when a drive is over: shows the results
 * The loop advances and draws the drive, or draws the garage, or a scenic backdrop for menus.
 */
'use strict';

SW.Game = (() => {
  const C = SW.CFG;
  const $ = SW.util.$;
  let canvas;
  let ctx;
  let mission = null;
  let paused = false;
  let last = performance.now();
  let t = 0;
  let backdrop = null;

  function boot() {
    canvas = $('view');
    ctx = canvas.getContext('2d');
    resize();
    addEventListener('resize', resize);
    SW.Input.init();
    SW.UI.init();
    SW.Garage.init();
    SW.UI.go('title');
    document.body.classList.add('ready');
    requestAnimationFrame(frame);
  }

  function resize() {
    const dpr = Math.min(2, devicePixelRatio || 1);
    canvas.width = Math.round(innerWidth * dpr);
    canvas.height = Math.round(innerHeight * dpr);
    SW.Garage.layout();
  }

  function drive(m) {
    const bp = SW.Garage.blueprint() || SW.Save.profile().bench;
    const problems = m.test
      ? SW.Blueprint.analyze(bp).errors
      : SW.Blueprint.missionProblems(bp, m, SW.Save.profile().inventory);
    if (problems.length) {
      SW.UI.go('garage', m.test ? null : m);
      SW.UI.toast(problems[0]);
      return false;
    }
    mission = m;
    paused = false;
    SW.Input.clear();
    SW.UI.go('drive');
    SW.Run.start(m, bp);
    return true;
  }

  function restart() {
    if (mission) drive(mission);
  }

  function toGarage() {
    SW.Run.stop();
    SW.Audio.drive(null);
    SW.UI.go('garage', mission && !mission.test ? mission : null);
  }

  function pause(on) {
    if (SW.UI.screen() !== 'drive') return;
    const run = SW.Run.current();
    if (!run || run.status === 'over') return;
    paused = on;
    if (on) SW.UI.openModal('pause');
    else SW.UI.closeModal();
  }

  function runEnded(result) {
    SW.Audio.drive(null);
    SW.UI.openModal('result', result);
  }

  function key(e) {
    if (e.code === 'Escape') {
      if (SW.UI.back()) return;
      const screen = SW.UI.screen();
      if (screen === 'drive') {
        const run = SW.Run.current();
        if (run && run.status === 'over') toGarage();
        else pause(!paused);
      } else if (screen === 'garage') SW.UI.go('missions');
      else if (screen !== 'title') SW.UI.go('title');
      return;
    }
    if (SW.UI.screen() === 'drive') {
      if (e.code === 'KeyR') restart();
      if (e.code === 'Space') e.preventDefault();
      return;
    }
    if (SW.UI.screen() === 'garage' && !SW.UI.modal()) SW.Garage.keys(e);
  }

  function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    t += dt;
    const dpr = canvas.width / innerWidth;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const screen = SW.UI.screen();
    const run = SW.Run.current();
    if (screen === 'drive' && run) {
      if (!paused) {
        SW.Run.update(dt, SW.Input.state());
        SW.Effects.update(dt);
      }
      SW.Render.draw(ctx, run, innerWidth, innerHeight, t);
      SW.HUD.update(run, dt);
      SW.Audio.drive(run.status === 'driving' && !paused ? run.v : null);
    } else if (screen === 'garage') {
      SW.Garage.draw(t);
    } else {
      scenery(dt);
    }
  }

  // Menu backdrop: an empty vehicle-free course scrolling slowly by.
  function scenery(dt) {
    if (!backdrop) {
      const m = C.MISSIONS[1];
      const track = SW.Track.build(m, 3);
      backdrop = {
        mission: m,
        track,
        state: { planks: [], rocks: [], pickups: [], debris: [] },
        v: { blocks: [], wheels: [] },
        cam: { x: 10, y: 3, zoom: 0.8 },
        shake: 0,
      };
    }
    backdrop.cam.x += dt * 4;
    if (backdrop.cam.x > backdrop.track.end - 40) backdrop.cam.x = 10;
    const h = backdrop.track.heightAt(backdrop.cam.x);
    backdrop.cam.y += ((h === null ? 0 : h) + 2 - backdrop.cam.y) * Math.min(1, dt * 2);
    SW.Render.draw(ctx, backdrop, innerWidth, innerHeight, t);
  }

  return { boot, drive, restart, toGarage, pause, runEnded, key, mission: () => mission };
})();

SW.Game.boot();
