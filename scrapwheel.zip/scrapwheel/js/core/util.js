/*
 * Shared helpers. Every script adds to the single global SW namespace created here.
 *   SW.util.rng(seed)    seeded random numbers (mulberry32): a seed always builds the same track
 *   SW.util.noise(seed)  smooth 1D value noise for rolling terrain
 *   esc()                HTML escaping for anything the player typed (build names)
 */
'use strict';

const SW = {};

SW.util = (() => {
  function rng(seed) {
    let a = seed >>> 0;
    return () => {
      a = (a + 0x6d2b79f5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // Smooth noise in [-1, 1]: noise(seed)(x) changes gently, about once per unit of x.
  function noise(seed) {
    const r = rng(seed);
    const table = [];
    for (let i = 0; i < 512; i++) table.push(r() * 2 - 1);
    return x => {
      const i = Math.floor(x);
      const f = x - i;
      const s = f * f * (3 - 2 * f);
      return table[i & 511] * (1 - s) + table[(i + 1) & 511] * s;
    };
  }

  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const lerp = (a, b, t) => a + (b - a) * t;

  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const esc = s => String(s).replace(/[&<>"']/g, c => ESC[c]);
  const $ = id => document.getElementById(id);

  function time(s) {
    if (!Number.isFinite(s)) return '–';
    const m = Math.floor(s / 60);
    const sec = s - m * 60;
    return m + ':' + sec.toFixed(1).padStart(4, '0');
  }

  return { rng, noise, clamp, lerp, esc, $, time };
})();
