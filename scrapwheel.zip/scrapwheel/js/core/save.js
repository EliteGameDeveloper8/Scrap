/*
 * Everything kept on the device, in localStorage:
 *   sw_profile    coins, owned parts, mission progress (stars, best times), the build on the bench
 *   sw_builds     saved vehicle builds (name, cells, suspension)
 *   sw_settings   sound and display settings
 * Builds can also be shared as a short text code (export / import).
 */
'use strict';

SW.Save = (() => {
  const C = SW.CFG;
  const KEYS = { profile: 'sw_profile', builds: 'sw_builds', settings: 'sw_settings' };
  const SETTINGS = { sound: true, particles: true, shake: true };
  let profile = null;
  let settings = null;

  function read(key, fallback) {
    try {
      const v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch (e) {
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      return false;
    }
  }

  function freshProfile() {
    return {
      v: 1,
      coins: C.START.coins,
      inventory: Object.assign({}, C.START.inventory),
      missions: {}, // id -> { stars: [bool, bool, bool], best: seconds, done: true }
      bench: SW.Blueprint.clone(C.START.build),
      lastMission: C.MISSIONS[0].id,
    };
  }

  function getProfile() {
    if (!profile) {
      profile = read(KEYS.profile, null) || freshProfile();
      // repair anything missing or malformed
      const fresh = freshProfile();
      for (const k of Object.keys(fresh)) if (profile[k] === undefined || profile[k] === null) profile[k] = fresh[k];
      if (!Number.isFinite(profile.coins)) profile.coins = fresh.coins;
      for (const k of Object.keys(profile.inventory)) {
        if (!C.PARTS[k] || !Number.isFinite(profile.inventory[k])) delete profile.inventory[k];
      }
      profile.inventory.seat = 1;
      profile.bench = SW.Blueprint.sanitize(profile.bench) || fresh.bench;
    }
    return profile;
  }

  const saveProfile = () => write(KEYS.profile, getProfile());

  function resetProfile() {
    profile = freshProfile();
    saveProfile();
  }

  // ---- builds ----

  const builds = () => (read(KEYS.builds, []) || []).filter(b => b && b.id).sort((a, b) => b.updated - a.updated);

  function storeBuild(bp, name) {
    const list = builds();
    const clean =
      String(name || 'My vehicle')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 30) || 'My vehicle';
    const existing = list.find(b => b.name === clean);
    const entry = Object.assign(SW.Blueprint.clone(bp), {
      id: existing ? existing.id : 'b' + Date.now().toString(36) + Math.floor(Math.random() * 1e4),
      name: clean,
      updated: Date.now(),
    });
    const next = list.filter(b => b.id !== entry.id).concat(entry);
    return write(KEYS.builds, next) ? entry : null;
  }

  function removeBuild(id) {
    write(
      KEYS.builds,
      builds().filter(b => b.id !== id),
    );
  }

  // Share codes: "SW1:" + base64 of the compact build.
  function exportCode(bp) {
    const data = { s: bp.susp, c: bp.cells };
    return 'SW1:' + btoa(unescape(encodeURIComponent(JSON.stringify(data))));
  }

  function importCode(code) {
    const text = String(code || '').trim();
    if (!text.startsWith('SW1:')) throw new Error('That is not a Scrapwheel build code.');
    let data;
    try {
      data = JSON.parse(decodeURIComponent(escape(atob(text.slice(4)))));
    } catch (e) {
      throw new Error('That build code is damaged. Copy it again and paste the whole code.');
    }
    const bp = SW.Blueprint.sanitize({ name: 'Imported build', susp: data.s, cells: data.c });
    if (!bp || !bp.cells.length) throw new Error('That build code has no parts in it.');
    return bp;
  }

  // ---- settings ----

  function getSettings() {
    if (!settings) settings = Object.assign({}, SETTINGS, read(KEYS.settings, {}));
    return settings;
  }

  function setSetting(key, value) {
    getSettings()[key] = value;
    write(KEYS.settings, settings);
  }

  return {
    profile: getProfile,
    saveProfile,
    resetProfile,
    builds,
    storeBuild,
    removeBuild,
    exportCode,
    importCode,
    settings: getSettings,
    setSetting,
  };
})();
