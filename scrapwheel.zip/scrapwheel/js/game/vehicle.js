/*
 * A blueprint turned into a physics vehicle.
 *
 * All blocks that hold together share one rigid body (one fixture per block), so the frame is
 * solid. Wheels are separate bodies on suspension (wheel joints) with motors driven by the engines.
 * The driver's head is a sensor above the seat: if it touches the ground, the run is over.
 *
 * Blocks take damage from hard hits. When a block breaks it falls off as debris, and any part of
 * the frame no longer joined to the seat splits away as its own body, taking its wheels, engines,
 * tanks and boosters with it. Only what is still attached to the seat keeps working.
 */
'use strict';

SW.Vehicle = (() => {
  const pl = planck;
  const C = SW.CFG;
  const V = SW.World.V;
  const H = C.CELL / 2;

  // Wedge corners at rotation 0 (slope facing up and forward); other rotations turn it clockwise.
  function wedgeVerts(rot, cx, cy) {
    const base = [
      [-H, -H],
      [H, -H],
      [-H, H],
    ];
    const a = (-rot * Math.PI) / 2;
    return base.map(([x, y]) => V(cx + x * Math.cos(a) - y * Math.sin(a), cy + x * Math.sin(a) + y * Math.cos(a)));
  }

  function blockShape(b) {
    if (b.part === 'wedge') return pl.Polygon(wedgeVerts(b.rot, b.lx, b.ly));
    return pl.Box(H, H, V(b.lx, b.ly), 0);
  }

  // Booster thrust direction in the vehicle's frame: rotation 0 pushes forward (+x), each
  // rotation turns it a quarter clockwise (as the builder shows it).
  function thrustDir(rot) {
    return [
      [1, 0],
      [0, -1],
      [-1, 0],
      [0, 1],
    ][rot & 3];
  }

  function create(world, bp, x, groundY) {
    const analysis = SW.Blueprint.analyze(bp);
    const susp = C.SUSPENSION[bp.susp] || C.SUSPENSION.normal;
    const cells = bp.cells.filter(c => !analysis.loose.has(SW.Blueprint.key(c[0], c[1])));
    const ox = (C.COLS - 1) / 2;
    const oy = (C.ROWS - 1) / 2;
    const local = (c, r) => [(c - ox) * C.CELL, (oy - r) * C.CELL];

    // lift the vehicle so its lowest point starts just above the ground
    let lowest = Infinity;
    for (const [c, r, part] of cells) {
      const [, ly] = local(c, r);
      const P = C.PARTS[part];
      lowest = Math.min(lowest, ly - (P.kind === 'wheel' ? P.radius : H));
    }
    const y = groundY - lowest + 0.35;

    const v = {
      world,
      blocks: [],
      wheels: [],
      main: null,
      head: null,
      seat: null,
      fuel: 0,
      fuelMax: 0,
      stats: {},
      susp,
      headHit: false,
      seatLost: false,
      boosting: false,
      throttle: 0,
    };
    const body = world.createBody({ type: 'dynamic', position: V(x, y), linearDamping: 0.02, angularDamping: 0.05 });
    v.main = body;

    for (const [c, r, part, rot] of cells) {
      const P = C.PARTS[part];
      if (P.kind !== 'block') continue;
      const [lx, ly] = local(c, r);
      const b = { c, r, part, rot, lx, ly, hp: P.hp, max: P.hp, alive: true, body, fixture: null, hit: 0 };
      b.fixture = body.createFixture(blockShape(b), {
        density: P.mass / (C.CELL * C.CELL) / (part === 'wedge' ? 0.5 : 1),
        friction: P.friction || 0.6,
        restitution: P.bounce || 0.05,
        userData: { type: 'block', block: b, vehicle: v },
      });
      v.blocks.push(b);
      if (part === 'seat') {
        v.seat = b;
        v.head = body.createFixture(pl.Circle(V(lx, ly + 0.32), 0.15), {
          isSensor: true,
          userData: { type: 'head', vehicle: v },
        });
      }
    }

    const byCell = new Map(v.blocks.map(b => [SW.Blueprint.key(b.c, b.r), b]));
    for (const [c, r, part] of cells) {
      const P = C.PARTS[part];
      if (P.kind !== 'wheel') continue;
      const host = analysis.attached.get(SW.Blueprint.key(c, r));
      const attach = host && byCell.get(SW.Blueprint.key(host[0], host[1]));
      if (!attach) continue;
      const [lx, ly] = local(c, r);
      const wb = world.createBody({ type: 'dynamic', position: V(x + lx, y + ly), angularDamping: 0.05 });
      wb.createFixture(pl.Circle(P.radius), {
        density: P.mass / (Math.PI * P.radius * P.radius),
        friction: P.friction,
        restitution: 0.1,
        userData: { type: 'wheel', vehicle: v },
      });
      const w = { c, r, part, radius: P.radius, body: wb, joint: null, attach };
      joinWheel(v, w, body);
      v.wheels.push(w);
    }

    refreshStats(v);
    v.fuel = v.fuelMax;
    return v;
  }

  function joinWheel(v, w, frame) {
    if (w.joint) v.world.destroyJoint(w.joint);
    const axis = frame.getWorldVector(V(0, 1));
    w.joint = v.world.createJoint(
      pl.WheelJoint(
        { enableMotor: true, maxMotorTorque: 0, motorSpeed: 0, frequencyHz: v.susp.hz, dampingRatio: v.susp.damping },
        frame,
        w.body,
        w.body.getPosition(),
        axis,
      ),
    );
  }

  // Power, thrust, fuel and so on, counting only parts still attached to the seat.
  function refreshStats(v) {
    const s = { power: 0, thrust: 0, gyro: 0, fuel: C.BASE_FUEL, boosters: [] };
    for (const b of v.blocks) {
      if (!b.alive || b.body !== v.main) continue;
      const P = C.PARTS[b.part];
      s.power += P.power || 0;
      s.gyro += P.gyro || 0;
      s.fuel += P.fuel || 0;
      if (P.thrust) s.boosters.push(b);
    }
    s.drive = v.wheels.filter(w => w.joint && w.attach.alive && w.attach.body === v.main);
    v.stats = s;
    v.fuelMax = s.fuel * (v.fuelScale || 1);
    v.fuel = Math.min(v.fuel, v.fuelMax);
  }

  // Applies the player's controls for one physics step.
  function control(v, input, dt) {
    const s = v.stats;
    const hasFuel = v.fuel > 0;
    const throttle = hasFuel ? input.throttle : 0;
    v.throttle = throttle;
    const top = s.power ? C.BASE_SPEED + (s.power - 1) * C.SPEED_PER_ENGINE : 0;
    const n = s.drive.length;
    for (const w of s.drive) {
      if (throttle && s.power) {
        w.joint.setMotorSpeed((-throttle * top) / w.radius);
        w.joint.setMaxMotorTorque(((s.power * C.ENGINE_FORCE) / n) * w.radius);
      } else {
        w.joint.setMotorSpeed(0);
        w.joint.setMaxMotorTorque(input.brake ? 40 * w.radius : 0.4);
      }
    }

    const body = v.main;
    if (input.lean) {
      const accel = C.LEAN + C.LEAN_PER_GYRO * s.gyro;
      const w = body.getAngularVelocity();
      if (Math.abs(w) < 5 || Math.sign(w) !== Math.sign(input.lean))
        body.applyTorque(input.lean * accel * body.getInertia());
    }

    v.boosting = !!(input.boost && hasFuel && s.boosters.length);
    if (v.boosting) {
      for (const b of s.boosters) {
        const [dx, dy] = thrustDir(b.rot);
        const dir = body.getWorldVector(V(dx, dy));
        body.applyForce(V(dir.x * C.BOOST_FORCE, dir.y * C.BOOST_FORCE), body.getWorldPoint(V(b.lx, b.ly)));
      }
    }
    const burn =
      Math.abs(throttle) * s.power * C.FUEL_PER_ENGINE + (v.boosting ? s.boosters.length * C.FUEL_PER_BOOSTER : 0);
    v.fuel = Math.max(0, v.fuel - burn * dt);
  }

  // Applies the hits collected during the step; breaks blocks that run out of hp.
  // Returns the broken blocks (for effects).
  function applyDamage(v, state) {
    const broken = [];
    for (const b of v.blocks) {
      if (!b.alive || !b.hit) continue;
      const P = C.PARTS[b.part];
      const dmg = Math.max(0, b.hit - C.DAMAGE.threshold) * C.DAMAGE.scale * (P.armor || 1);
      b.hit = 0;
      if (!dmg) continue;
      b.hp -= dmg;
      if (b.hp <= 0) broken.push(b);
    }
    for (const b of broken) breakBlock(v, state, b);
    if (broken.length) refreshStats(v);
    return broken;
  }

  function breakBlock(v, state, b) {
    if (!b.alive) return;
    const body = b.body;
    const pos = body.getWorldPoint(V(b.lx, b.ly));
    const vel = body.getLinearVelocityFromWorldPoint(pos);
    const shape = b.part === 'wedge' ? pl.Polygon(wedgeVerts(b.rot, 0, 0)) : pl.Box(H, H);
    SW.World.addDebris(state, shape, pos.x, pos.y, body.getAngle(), vel, body.getAngularVelocity(), b.part, b.rot);
    body.destroyFixture(b.fixture);
    b.alive = false;
    if (b === v.seat) {
      if (v.head) body.destroyFixture(v.head);
      v.head = null;
      v.seatLost = true;
    }
    for (const w of v.wheels) {
      if (w.attach === b && w.joint) {
        v.world.destroyJoint(w.joint);
        w.joint = null;
      }
    }
    split(v, body);
  }

  // Splits a body into one body per group of blocks that still touch each other.
  function split(v, body) {
    const own = v.blocks.filter(b => b.alive && b.body === body);
    const at = new Map(own.map(b => [SW.Blueprint.key(b.c, b.r), b]));
    const seen = new Set();
    const groups = [];
    for (const start of own) {
      if (seen.has(start)) continue;
      const group = [];
      const stack = [start];
      seen.add(start);
      while (stack.length) {
        const b = stack.pop();
        group.push(b);
        for (const [dc, dr] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ]) {
          const n = at.get(SW.Blueprint.key(b.c + dc, b.r + dr));
          if (n && !seen.has(n)) {
            seen.add(n);
            stack.push(n);
          }
        }
      }
      groups.push(group);
    }
    if (groups.length < 2) return;
    // the group with the seat (or the biggest) stays on the body
    groups.sort((a, b) => (b.includes(v.seat) ? 1e6 : b.length) - (a.includes(v.seat) ? 1e6 : a.length));
    for (const group of groups.slice(1)) {
      const nb = v.world.createBody({
        type: 'dynamic',
        position: body.getPosition(),
        angle: body.getAngle(),
        linearDamping: 0.02,
        angularDamping: 0.05,
      });
      for (const b of group) {
        const P = C.PARTS[b.part];
        const fixture = b.fixture;
        b.fixture = nb.createFixture(blockShape(b), {
          density: fixture.getDensity(),
          friction: P.friction || 0.6,
          restitution: P.bounce || 0.05,
          userData: { type: 'debris', block: b },
        });
        body.destroyFixture(fixture);
        b.body = nb;
      }
      nb.setLinearVelocity(body.getLinearVelocity());
      nb.setAngularVelocity(body.getAngularVelocity());
      for (const w of v.wheels) if (w.joint && group.includes(w.attach)) joinWheel(v, w, nb);
    }
  }

  function destroyAll(v) {
    v.blocks = [];
    v.wheels = [];
  }

  return { create, control, applyDamage, refreshStats, thrustDir, wedgeVerts, destroyAll };
})();
