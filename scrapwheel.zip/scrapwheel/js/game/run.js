/*
 * One drive: builds the track, the physics world and the vehicle, steps the simulation at a
 * fixed rate, applies the controls, watches for the finish and for every way to fail, and
 * pays out coins, stars and parts at the end.
 *
 *   SW.Run.start(mission, blueprint)   begin a drive (mission or the test track)
 *   SW.Run.update(dt, input)           advance it; calls SW.Game.runEnded(result) when it is over
 *   SW.Run.current()                   the drive in progress (read by the renderer and HUD)
 */
'use strict';

SW.Run = (() => {
  const C = SW.CFG;
  const U = SW.util;
  const DAMAGING = new Set(['ground', 'roof', 'rock', 'plank', 'debris']);
  let run = null;

  function seedFor(mission) {
    if (mission.test) return Math.floor(Math.random() * 1e9);
    let h = 7;
    for (const ch of mission.id) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
    return h;
  }

  function start(mission, bp) {
    stop();
    const track = SW.Track.build(mission, seedFor(mission));
    const state = SW.World.create(track, mission.gravity || C.GRAVITY);
    state.theme = mission.theme;
    const v = SW.Vehicle.create(state.world, bp, track.start, track.heightAt(track.start));
    v.fuelScale = mission.fuelScale || 1;
    SW.Vehicle.refreshStats(v);
    v.fuel = v.fuelMax;
    run = {
      mission,
      bp: SW.Blueprint.clone(bp),
      track,
      state,
      v,
      crate: null,
      time: 0,
      acc: 0,
      coins: 0,
      fuelCans: 0,
      status: 'driving', // 'driving' | 'ending' | 'over'
      endTimer: 0,
      result: null,
      maxX: track.start,
      stuck: 0,
      empty: 0,
      shake: 0,
      cam: { x: track.start + 4, y: track.heightAt(track.start) + 2, zoom: 1 },
    };
    if (mission.goal === 'deliver') loadCrate(run);
    listen(run);
    SW.Effects.reset();
    return run;
  }

  // The crate is loaded onto the highest cargo bed, in the first free space above it.
  function loadCrate(r) {
    const beds = r.v.blocks.filter(b => b.part === 'bed' && b.alive).sort((a, b) => a.r - b.r);
    const bed = beds[0];
    if (!bed) return;
    const taken = new Set(r.v.blocks.map(b => b.c + ',' + b.r));
    let row = bed.r - 1;
    while (row > -4 && (taken.has(bed.c + ',' + row) || taken.has(bed.c + 1 + ',' + row))) row--;
    const lift = (bed.r - row - 1) * C.CELL;
    const p = r.v.main.getWorldPoint(SW.World.V(bed.lx + C.CELL / 2, bed.ly + lift + C.CELL / 2 + 0.32));
    const body = r.state.world.createBody({ type: 'dynamic', position: p });
    const w = 0.8;
    const h = 0.6;
    body.createFixture(planck.Box(w / 2, h / 2), {
      density: r.mission.cargo / (w * h),
      friction: 0.75,
      restitution: 0.05,
      userData: { type: 'cargo' },
    });
    r.crate = { body, w, h };
  }

  function listen(r) {
    const world = r.state.world;
    world.on('post-solve', (contact, impulse) => {
      const a = contact.getFixtureA().getUserData() || {};
      const b = contact.getFixtureB().getUserData() || {};
      const imp = Math.max(...impulse.normalImpulses);
      if (!(imp > 0)) return;
      for (const [me, other] of [
        [a, b],
        [b, a],
      ]) {
        if (me.type === 'block' && DAMAGING.has(other.type)) {
          me.block.hit = Math.max(me.block.hit, imp);
          if (imp > C.DAMAGE.threshold * 2) {
            const wm = contact.getWorldManifold(null);
            const pt = wm && wm.points[0];
            if (pt) SW.Effects.impact(pt.x, pt.y, imp);
            r.shake = Math.min(1, r.shake + imp / 60);
          }
        }
      }
    });
    world.on('begin-contact', contact => {
      const a = contact.getFixtureA().getUserData() || {};
      const b = contact.getFixtureB().getUserData() || {};
      for (const [me, other] of [
        [a, b],
        [b, a],
      ]) {
        if (me.type === 'head' && ['ground', 'roof', 'rock', 'plank'].includes(other.type)) r.v.headHit = true;
        if ((me.type === 'coin' || me.type === 'fuel') && ['block', 'wheel', 'head', 'cargo'].includes(other.type)) {
          const p = me.pickup;
          if (p.taken) continue;
          p.taken = true;
          SW.World.remove(r.state, p.body);
          if (p.type === 'coin') {
            r.coins++;
            SW.Audio.play('coin');
          } else {
            r.v.fuel = Math.min(r.v.fuelMax, r.v.fuel + 30);
            r.fuelCans++;
            SW.Audio.play('fuel');
          }
          SW.Effects.sparkle(p.x, p.y, p.type === 'coin' ? '#ffd34d' : '#ff6b4a');
        }
      }
    });
  }

  function update(dt, input) {
    if (!run || run.status === 'over') return;
    const slow = run.status === 'ending' ? 0.3 : 1;
    run.acc += Math.min(dt, 0.1) * slow;
    while (run.acc >= C.STEP) {
      run.acc -= C.STEP;
      step(run.status === 'driving' ? input : { throttle: 0, lean: 0, boost: false, brake: false });
      if (run.status === 'over') return;
    }
    if (run.status === 'ending') {
      run.endTimer -= dt;
      if (run.endTimer <= 0) finish();
    }
    camera(dt);
    run.shake = Math.max(0, run.shake - dt * 2.5);
  }

  function step(input) {
    const r = run;
    const v = r.v;
    if (r.status === 'driving') {
      SW.Vehicle.control(v, input, C.STEP);
      if (r.mission.test) v.fuel = v.fuelMax;
      r.time += C.STEP;
    }
    r.state.world.step(C.STEP, 10, 8);
    SW.World.flush(r.state);
    const broken = SW.Vehicle.applyDamage(v, r.state);
    for (const b of broken) {
      const p = b.body.getWorldPoint(SW.World.V(b.lx, b.ly));
      SW.Effects.shatter(p.x, p.y, b.part);
      SW.Audio.play('break');
    }
    SW.Effects.vehicle(v, r.state, C.STEP);
    for (const d of r.state.debris) d.age += C.STEP;
    if (r.status === 'driving') check(r);
  }

  function check(r) {
    const v = r.v;
    const pos = v.main.getPosition();
    const speed = v.main.getLinearVelocity().length();
    const t = r.track;
    r.maxX = Math.max(r.maxX, pos.x);

    if (v.headHit)
      return fail(
        'Your driver bumped their head!',
        'Protect the seat with a roof, or keep the vehicle upright with W / S.',
      );
    if (v.seatLost) return fail('The driver’s seat broke off!', 'Use tougher blocks (steel, rubber) around the seat.');
    if (fell(t, pos)) return fail('You fell!', 'Take the jumps faster, or add boosters to clear the gaps.');
    if (r.crate) {
      const cp = r.crate.body.getPosition();
      if (fell(t, cp) || cp.x < pos.x - 14)
        return fail('You lost the crate!', 'Build walls around the cargo bed and take it easy over bumps.');
    }
    if (v.fuel <= 0 && speed < 0.4) {
      r.empty += C.STEP;
      if (r.empty > 2.5)
        return fail('Out of fuel.', 'Add fuel tanks, pick up the red fuel cans, or use fewer engines.');
    } else r.empty = 0;

    if (t.finish !== null && pos.x >= t.finish) {
      if (!r.crate || r.crate.body.getPosition().x >= t.finish) return win();
    }
    if (t.finish === null && pos.x >= t.end - 42)
      return fail('End of the test track.', 'Head back to the garage to tweak your build.', true);
  }

  function fell(t, p) {
    if (p.y < t.minY - 25) return true;
    return t.pits.some(pit => p.x > pit.x0 && p.x < pit.x1 && p.y < pit.bottom + 9);
  }

  function fail(reason, hint, neutral) {
    run.status = 'ending';
    run.endTimer = neutral ? 0.2 : 1.2;
    run.result = { win: false, reason, hint, neutral };
    if (!neutral) SW.Audio.play('crash');
  }

  function win() {
    run.status = 'ending';
    run.endTimer = 0.9;
    run.result = { win: true };
    SW.Audio.play('win');
  }

  // Works out stars and rewards and saves them.
  function finish() {
    const r = run;
    r.status = 'over';
    const res = Object.assign(r.result, {
      mission: r.mission,
      time: r.time,
      coins: r.coins,
      distance: r.maxX - r.track.start,
    });
    if (res.win && !r.mission.test) Object.assign(res, award(r));
    SW.Game.runEnded(res);
  }

  function award(r) {
    const prof = SW.Save.profile();
    const m = r.mission;
    const rec = prof.missions[m.id] || { stars: [false, false, false], best: null, done: false };
    const stars = [true, r.time <= m.par, r.bp.cells.length <= m.parts];
    const newStars = stars.filter((s, i) => s && !rec.stars[i]).length;
    const first = !rec.done;
    const coins = r.coins * C.COIN_VALUE + newStars * C.STAR_COINS;
    rec.stars = rec.stars.map((s, i) => s || stars[i]);
    rec.best = rec.best === null ? r.time : Math.min(rec.best, r.time);
    rec.done = true;
    prof.missions[m.id] = rec;
    prof.coins += coins;
    const reward = first ? m.reward : null;
    if (reward) for (const [part, n] of Object.entries(reward)) prof.inventory[part] = (prof.inventory[part] || 0) + n;
    const i = C.MISSIONS.indexOf(m);
    if (C.MISSIONS[i + 1]) prof.lastMission = C.MISSIONS[i + 1].id;
    SW.Save.saveProfile();
    return { stars, newStars, earned: coins, reward, best: rec.best };
  }

  function camera(dt) {
    const r = run;
    const p = r.v.main.getPosition();
    const vel = r.v.main.getLinearVelocity();
    const k = 1 - Math.exp(-dt * 4);
    r.cam.x += (p.x + U.clamp(vel.x * 0.35, -4, 6) + 2 - r.cam.x) * k;
    r.cam.y += (p.y + 1 + U.clamp(vel.y * 0.15, -3, 3) - r.cam.y) * k;
    const target = 1 - Math.min(0.35, vel.length() / 50);
    r.cam.zoom += (target - r.cam.zoom) * Math.min(1, dt * 1.5);
  }

  function stop() {
    run = null;
  }

  return { start, update, stop, current: () => run };
})();
