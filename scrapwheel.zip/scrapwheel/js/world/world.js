/*
 * The physics world (planck.js, a port of Box2D) for one drive: the ground, tunnel roofs,
 * loose rocks, rope bridges, coins and fuel cans.
 *
 * Every fixture carries userData { type, ... } so contact handlers know what touched what:
 *   ground, roof, rock, plank       the course
 *   coin, fuel                      pickups (sensors)
 *   block, wheel, head, cargo       the vehicle and its load (see SW.Vehicle)
 *   debris                          parts that broke off
 */
'use strict';

SW.World = (() => {
  const pl = planck;
  const V = (x, y) => pl.Vec2(x, y);

  function create(track, gravity) {
    const world = pl.World({ gravity: V(0, -gravity) });
    const state = { world, track, rocks: [], planks: [], pickups: [], debris: [], removeQueue: [] };

    const ground = world.createBody();
    for (const piece of track.pieces) {
      ground.createFixture(
        pl.Chain(
          piece.map(p => V(p.x, p.y)),
          false,
        ),
        {
          friction: 0.9,
          userData: { type: 'ground' },
        },
      );
    }
    for (const roof of track.roofs) {
      ground.createFixture(
        pl.Chain(
          roof.map(p => V(p.x, p.y)),
          false,
        ),
        {
          friction: 0.5,
          userData: { type: 'roof' },
        },
      );
    }

    for (const rk of track.rocks) {
      const r = SW.util.rng(rk.seed);
      const verts = [];
      const n = 6 + Math.floor(r() * 3);
      for (let i = 0; i < n; i++) {
        const a = (i / n) * Math.PI * 2;
        const d = rk.r * (0.75 + r() * 0.3);
        verts.push(V(Math.cos(a) * d, Math.sin(a) * d));
      }
      const body = world.createBody({ type: 'dynamic', position: V(rk.x, rk.y), angle: r() * 6 });
      body.createFixture(pl.Polygon(verts), { density: 2.2, friction: 0.8, userData: { type: 'rock' } });
      state.rocks.push({ body, verts: verts.map(v => ({ x: v.x, y: v.y })) });
    }

    for (const br of track.bridges) bridge(state, ground, br);

    for (const c of track.coins) pickup(state, 'coin', c.x, c.y, 0.32);
    for (const f of track.fuel) pickup(state, 'fuel', f.x, f.y, 0.45);
    return state;
  }

  // A rope bridge: planks joined end to end, pinned to the ground at both edges.
  function bridge(state, ground, br) {
    const { world } = state;
    const len = Math.hypot(br.x1 - br.x0, br.y1 - br.y0);
    const n = Math.max(4, Math.round(len / 1.1));
    const step = len / n;
    const dx = (br.x1 - br.x0) / len;
    const dy = (br.y1 - br.y0) / len;
    const angle = Math.atan2(dy, dx);
    let prev = ground;
    for (let i = 0; i < n; i++) {
      const cx = br.x0 + dx * step * (i + 0.5);
      const cy = br.y0 + dy * step * (i + 0.5) - 0.1;
      const body = world.createBody({
        type: 'dynamic',
        position: V(cx, cy),
        angle,
        linearDamping: 0.2,
        angularDamping: 0.4,
      });
      body.createFixture(pl.Box(step / 2 - 0.02, 0.1), { density: 6, friction: 0.9, userData: { type: 'plank' } });
      const anchor = V(br.x0 + dx * step * i, br.y0 + dy * step * i - 0.1);
      world.createJoint(pl.RevoluteJoint({}, prev, body, anchor));
      state.planks.push({ body, w: step });
      prev = body;
    }
    world.createJoint(pl.RevoluteJoint({}, prev, ground, V(br.x1, br.y1 - 0.1)));
  }

  function pickup(state, type, x, y, r) {
    const body = state.world.createBody({ position: V(x, y) });
    const p = { type, x, y, body, taken: false };
    body.createFixture(pl.Circle(r), { isSensor: true, userData: { type, pickup: p } });
    state.pickups.push(p);
  }

  // A loose part: same shape, position and speed as the block it was.
  function addDebris(state, shape, x, y, angle, vel, angVel, part, rot) {
    const body = state.world.createBody({ type: 'dynamic', position: V(x, y), angle });
    body.createFixture(shape, { density: 4, friction: 0.7, userData: { type: 'debris' } });
    body.setLinearVelocity(vel);
    body.setAngularVelocity(angVel);
    const d = { body, part, rot, age: 0 };
    state.debris.push(d);
    if (state.debris.length > 40) remove(state, state.debris.shift().body);
    return d;
  }

  function remove(state, body) {
    state.removeQueue.push(body);
  }

  // Bodies can't be destroyed during a physics step: do it afterwards.
  function flush(state) {
    for (const b of state.removeQueue) state.world.destroyBody(b);
    state.removeQueue.length = 0;
  }

  return { create, addDebris, remove, flush, V };
})();
