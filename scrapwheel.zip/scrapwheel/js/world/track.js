/*
 * Track generation. A mission lists its track as segments; each segment adds a stretch of ground:
 *   ['flat', length]
 *   ['hills', length, height, frequency]   rolling hills from smooth noise
 *   ['climb', length, rise] / ['drop', length, fall]
 *   ['bumps', length, size]                 sharp little bumps
 *   ['rocks', length, count]                loose rocks lying on flat ground
 *   ['ramp', length, rise]                  a kicker, usually followed by a gap
 *   ['gap', width, landing height change]   a pit you must jump
 *   ['bridge', length]                      a pit spanned by a rope bridge of planks
 *   ['tunnel', length, height, floor]       a low rocky roof over 'flat', 'bumps' or 'rocks'
 * The result is plain data (ground pieces, roofs, pits, rocks, coins, fuel cans, finish line)
 * that SW.World turns into physics bodies and SW.Render draws.
 */
'use strict';

SW.Track = (() => {
  const U = SW.util;
  const START = 14; // flat run-up before the first segment
  const MAX_SLOPE = 0.34; // steepest rolling hill: rise per metre (about 19 degrees)
  const MAX_BEND = 0.06; // how fast a hill's slope may change per metre

  function build(mission, seed) {
    const r = U.rng(seed);
    const n = U.noise(seed + 1);
    const hill = t => n(t) + 0.45 * n(t * 2.3 + 40);
    const pieces = [];
    const roofs = [];
    const pits = [];
    const rocks = [];
    const bridges = [];
    const coinSpots = [];
    const coins = [];
    let pts = [];
    let x = -6;
    let y = 0;

    const add = (px, py) => {
      const last = pts[pts.length - 1];
      if (!last || px - last.x > 0.05 || Math.abs(py - last.y) > 0.05) pts.push({ x: px, y: py });
    };
    const endPiece = () => {
      if (pts.length > 1) pieces.push(pts);
      pts = [];
    };

    // wall behind the start
    add(x, y + 20);
    add(x + 0.05, y);
    x = START;
    add(x, y);

    for (const seg of mission.track) {
      const [type, a, b, c] = seg;
      const x0 = x;
      const y0 = y;
      if (type === 'flat') {
        for (let k = 1; k <= Math.ceil(a); k++) add(x0 + Math.min(k, a), y0 + (r() - 0.5) * 0.06);
        x = x0 + a;
        y = pts[pts.length - 1].y;
      } else if (type === 'hills') {
        // rolling hills, with the slope limited so they stay drivable (climbs are their own segment)
        const base = hill(x0 * c);
        let py = y0;
        let slope = 0;
        for (let k = 1; k <= Math.ceil(a); k++) {
          const px = x0 + Math.min(k, a);
          const want = y0 + b * (hill(px * c) - base) * Math.min(1, k / 12);
          // follow the noise, but change the slope gradually so valleys and crests stay round
          slope += U.clamp(want - py - slope, -MAX_BEND, MAX_BEND);
          slope = U.clamp(slope, -MAX_SLOPE, MAX_SLOPE);
          py += slope;
          add(px, py);
        }
        x = x0 + a;
        y = pts[pts.length - 1].y;
        coinSpots.push([x0 + 4, x - 4]);
      } else if (type === 'climb' || type === 'drop') {
        for (let k = 1; k <= Math.ceil(a); k++) {
          const t = Math.min(k, a) / a;
          add(x0 + Math.min(k, a), y0 + b * (0.5 - 0.5 * Math.cos(t * Math.PI)));
        }
        x = x0 + a;
        y = y0 + b;
        coinSpots.push([x0 + 2, x - 2]);
      } else if (type === 'bumps') {
        bumps(x0, a, b);
        x = x0 + a;
        y = pts[pts.length - 1].y;
      } else if (type === 'rocks') {
        flatWithRocks(x0, a, b);
        x = x0 + a;
      } else if (type === 'ramp') {
        for (let k = 1; k <= Math.ceil(a); k++) {
          const t = Math.min(k, a) / a;
          add(x0 + Math.min(k, a), y0 + b * t * t);
        }
        x = x0 + a;
        y = y0 + b;
      } else if (type === 'gap' || type === 'bridge') {
        const width = a;
        const landing = y + (type === 'gap' ? b || 0 : 0);
        add(x, y - 14); // pit wall
        endPiece();
        pits.push({ x0: x, x1: x + width, bottom: Math.min(y, landing) - 14 });
        if (type === 'bridge') bridges.push({ x0: x, y0: y, x1: x + width, y1: landing });
        else coinArc(x, y, width, landing);
        x += width;
        y = landing;
        add(x, y - 14);
        add(x + 0.05, y);
        for (let k = 1; k <= 6; k++) add(x + k, y - k * 0.02);
        x += 6;
        y = pts[pts.length - 1].y;
      } else if (type === 'tunnel') {
        const height = b;
        const floor = c || 'flat';
        const roof = [];
        if (floor === 'bumps') bumps(x0, a, 0.35);
        else if (floor === 'rocks') flatWithRocks(x0, a, Math.round(a / 14));
        else for (let k = 1; k <= Math.ceil(a); k++) add(x0 + Math.min(k, a), y0);
        const groundY = y0;
        for (let k = 0; k <= Math.ceil(a); k++)
          roof.push({ x: x0 + Math.min(k, a), y: groundY + height + (k % 3 ? 0 : r() * 0.25) });
        roofs.push(roof);
        x = x0 + a;
        y = pts[pts.length - 1].y;
      }
    }

    function bumps(x0, len, size) {
      const base = pts[pts.length - 1].y;
      for (let px = x0 + 1.4; px < x0 + len; px += 1.4) {
        add(px - 0.7, base + size * (0.5 + r() * 0.7));
        add(px, base);
      }
      add(x0 + len, base);
    }

    function flatWithRocks(x0, len, count) {
      const base = pts[pts.length - 1].y;
      for (let k = 1; k <= Math.ceil(len); k++) add(x0 + Math.min(k, len), base);
      for (let i = 0; i < count; i++) {
        const rad = 0.18 + r() * 0.3;
        rocks.push({ x: x0 + 3 + r() * (len - 6), y: base + rad + 0.05, r: rad, seed: Math.floor(r() * 1e6) });
      }
    }

    function coinArc(gx, gy, width, landing) {
      for (let k = 1; k <= 5; k++) {
        const t = k / 6;
        coins.push({ x: gx + width * t, y: U.lerp(gy, landing, t) + 2.2 + Math.sin(t * Math.PI) * width * 0.18 });
      }
    }

    const finish = mission.test ? null : x + 4;
    for (let k = 1; k <= 40; k++) add(x + k, y);
    x += 40;
    add(x + 0.05, y + 20); // end wall
    endPiece();

    const all = pieces.flat();
    const heightAt = px => {
      for (const piece of pieces) {
        if (px < piece[0].x || px > piece[piece.length - 1].x) continue;
        for (let i = 1; i < piece.length; i++) {
          const p0 = piece[i - 1];
          const p1 = piece[i];
          if (px >= p0.x && px <= p1.x) return p0.y + ((p1.y - p0.y) * (px - p0.x)) / Math.max(1e-6, p1.x - p0.x);
        }
      }
      return null;
    };

    for (const [a, b] of coinSpots) {
      for (let px = a; px < b; px += 22) {
        for (let k = 0; k < 3; k++) {
          const cx = px + k * 1.2;
          const gy = heightAt(cx);
          if (gy !== null && !roofs.some(rf => cx >= rf[0].x && cx <= rf[rf.length - 1].x))
            coins.push({ x: cx, y: gy + 1.3 });
        }
      }
    }

    const fuel = (mission.fuelCans || []).map(fx => ({ x: START + fx, y: (heightAt(START + fx) || 0) + 0.9 }));

    return {
      pieces,
      roofs,
      pits,
      rocks,
      bridges,
      coins,
      fuel,
      start: 5,
      finish,
      end: x,
      minY: Math.min(...all.map(p => p.y)),
      maxY: Math.max(...all.map(p => p.y)),
      heightAt,
    };
  }

  return { build };
})();
