/*
 * Draws a drive: sky and parallax hills, the course (ground, tunnel roofs, pits, bridges,
 * rocks), pickups, flags, debris, the vehicle and its cargo, and particles.
 * The world is drawn in metres with y up; the camera comes from the run (SW.Run).
 */
'use strict';

SW.Render = (() => {
  const C = SW.CFG;
  const V = (x, y) => planck.Vec2(x, y);
  let farNoise = SW.util.noise(11);
  let midNoise = SW.util.noise(23);
  let stars = null;

  // Pixels per metre for a screen: about 9.5 metres fit vertically.
  const scaleFor = (w, h) => Math.max(28, Math.min(h / 9.5, w / (w < h ? 8 : 13)));

  function draw(ctx, run, W, H, t) {
    const theme = C.THEMES[run.mission.theme] || C.THEMES.meadow;
    const z = scaleFor(W, H) * run.cam.zoom;
    const shake = SW.Save.settings().shake ? run.shake * 0.25 : 0;
    const cx = run.cam.x + (Math.random() - 0.5) * shake;
    const cy = run.cam.y + (Math.random() - 0.5) * shake;
    background(ctx, theme, W, H, cx, cy, z);

    ctx.save();
    ctx.transform(z, 0, 0, -z, W / 2 - cx * z, H / 2 + cy * z); // on top of the device-pixel scale
    const view = { x0: cx - W / 2 / z - 2, x1: cx + W / 2 / z + 2, y0: cy - H / 2 / z - 2, y1: cy + H / 2 / z + 2 };
    const tr = run.track;

    for (const roof of tr.roofs) drawRoof(ctx, roof, theme, view);
    for (const pit of tr.pits) {
      if (pit.x1 < view.x0 || pit.x0 > view.x1) continue;
      const g = ctx.createLinearGradient(0, pit.bottom + 14, 0, pit.bottom);
      g.addColorStop(0, 'rgba(0,0,0,0.15)');
      g.addColorStop(1, 'rgba(0,0,0,0.6)');
      ctx.fillStyle = g;
      ctx.fillRect(pit.x0, pit.bottom - 30, pit.x1 - pit.x0, 44);
    }
    for (const piece of tr.pieces) drawGround(ctx, piece, theme, view);
    flags(ctx, tr, t);
    for (const p of run.state.planks) drawPlank(ctx, p);
    for (const rk of run.state.rocks) drawRock(ctx, rk);
    for (const p of run.state.pickups) if (!p.taken && p.x > view.x0 && p.x < view.x1) drawPickup(ctx, p, t);

    for (const d of run.state.debris) {
      ctx.save();
      body(ctx, d.body);
      ctx.globalAlpha = Math.max(0, 1 - Math.max(0, d.age - 5) / 2);
      ctx.scale(C.CELL, C.CELL);
      SW.Draw.part(ctx, d.part, d.rot, { damage: 1 });
      ctx.restore();
    }
    drawVehicle(ctx, run.v, t);
    if (run.crate) drawCrate(ctx, run.crate);
    SW.Effects.draw(ctx);
    ctx.restore();
  }

  function body(ctx, b) {
    const p = b.getPosition();
    ctx.translate(p.x, p.y);
    ctx.rotate(b.getAngle());
  }

  function background(ctx, theme, W, H, cx, cy, z) {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, theme.sky[0]);
    g.addColorStop(1, theme.sky[1]);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    if (theme.stars) {
      if (!stars) {
        const r = SW.util.rng(5);
        stars = Array.from({ length: 160 }, () => [r(), r() * 0.8, r() * 1.6 + 0.4]);
      }
      ctx.fillStyle = '#ffffff';
      for (const [x, y, s] of stars) ctx.fillRect((((x * W * 2 - cx * 2) % W) + W) % W, y * H, s, s);
      ctx.fillStyle = '#9fb0d0';
      ctx.beginPath();
      ctx.arc(W * 0.8, H * 0.2, Math.min(W, H) * 0.07, 0, Math.PI * 2);
      ctx.fill();
    }
    layer(ctx, theme.far, W, H, cx * 3, 0.12, farNoise, H * 0.5 + cy * 1.5, H * 0.3);
    layer(ctx, theme.mid, W, H, cx * 8, 0.25, midNoise, H * 0.68 + cy * 3, H * 0.22);
  }

  // A parallax hill silhouette.
  function layer(ctx, color, W, H, offset, freq, n, base, amp) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(0, H);
    for (let x = 0; x <= W + 20; x += 20) ctx.lineTo(x, base - amp * (0.5 + 0.5 * n(((x + offset) / W) * freq * 10)));
    ctx.lineTo(W, H);
    ctx.closePath();
    ctx.fill();
  }

  function visible(piece, view) {
    return !(piece[piece.length - 1].x < view.x0 || piece[0].x > view.x1);
  }

  function drawGround(ctx, piece, theme, view) {
    if (!visible(piece, view)) return;
    const pts = piece.filter(
      (p, i) =>
        (piece[i + 1] ? piece[i + 1].x : p.x) >= view.x0 - 3 && (piece[i - 1] ? piece[i - 1].x : p.x) <= view.x1 + 3,
    );
    if (pts.length < 2) return;
    const bottom = view.y0 - 5;
    ctx.beginPath();
    ctx.moveTo(pts[0].x, bottom);
    for (const p of pts) ctx.lineTo(p.x, p.y);
    ctx.lineTo(pts[pts.length - 1].x, bottom);
    ctx.closePath();
    const g = ctx.createLinearGradient(0, view.y1, 0, bottom);
    g.addColorStop(0, theme.ground);
    g.addColorStop(1, theme.deep);
    ctx.fillStyle = g;
    ctx.fill();
    ctx.beginPath();
    for (let i = 0; i < pts.length; i++) i ? ctx.lineTo(pts[i].x, pts[i].y) : ctx.moveTo(pts[i].x, pts[i].y);
    ctx.lineJoin = 'round';
    ctx.strokeStyle = theme.top;
    ctx.lineWidth = 0.32;
    ctx.stroke();
  }

  function drawRoof(ctx, roof, theme, view) {
    if (!visible(roof, view)) return;
    ctx.beginPath();
    ctx.moveTo(roof[0].x, view.y1 + 5);
    for (const p of roof) ctx.lineTo(p.x, p.y);
    ctx.lineTo(roof[roof.length - 1].x, view.y1 + 5);
    ctx.closePath();
    ctx.fillStyle = theme.deep;
    ctx.fill();
    ctx.beginPath();
    roof.forEach((p, i) => (i ? ctx.lineTo(p.x, p.y) : ctx.moveTo(p.x, p.y)));
    ctx.strokeStyle = 'rgba(0,0,0,0.35)';
    ctx.lineWidth = 0.18;
    ctx.stroke();
  }

  function drawPlank(ctx, p) {
    ctx.save();
    body(ctx, p.body);
    ctx.fillStyle = '#9a6b3e';
    ctx.fillRect(-p.w / 2 + 0.02, -0.1, p.w - 0.04, 0.2);
    ctx.strokeStyle = '#5e4228';
    ctx.lineWidth = 0.04;
    ctx.strokeRect(-p.w / 2 + 0.02, -0.1, p.w - 0.04, 0.2);
    ctx.restore();
  }

  function drawRock(ctx, rk) {
    ctx.save();
    body(ctx, rk.body);
    ctx.beginPath();
    rk.verts.forEach((v, i) => (i ? ctx.lineTo(v.x, v.y) : ctx.moveTo(v.x, v.y)));
    ctx.closePath();
    ctx.fillStyle = '#8a8580';
    ctx.fill();
    ctx.strokeStyle = '#5e5a55';
    ctx.lineWidth = 0.05;
    ctx.stroke();
    ctx.restore();
  }

  function drawPickup(ctx, p, t) {
    ctx.save();
    ctx.translate(p.x, p.y + Math.sin(t * 3 + p.x) * 0.08);
    if (p.type === 'coin') {
      const w = Math.abs(Math.cos(t * 3 + p.x * 0.7));
      ctx.scale(Math.max(0.15, w), 1);
      ctx.fillStyle = '#f2b51d';
      ctx.beginPath();
      ctx.arc(0, 0, 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffd34d';
      ctx.beginPath();
      ctx.arc(0, 0, 0.2, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = '#d9472b';
      SW.Draw.rr(ctx, -0.3, -0.38, 0.6, 0.72, 0.08);
      ctx.fill();
      ctx.fillStyle = '#2b2f36';
      ctx.fillRect(0.05, 0.34, 0.18, 0.12);
      ctx.strokeStyle = '#ffd34d';
      ctx.lineWidth = 0.07;
      ctx.beginPath();
      ctx.moveTo(-0.18, -0.2);
      ctx.lineTo(0.18, 0.2);
      ctx.moveTo(0.18, -0.2);
      ctx.lineTo(-0.18, 0.2);
      ctx.stroke();
    }
    ctx.restore();
  }

  function flags(ctx, tr, t) {
    const pole = (x, h, draw) => {
      const y = tr.heightAt(x);
      if (y === null) return;
      ctx.fillStyle = '#d9d9d9';
      ctx.fillRect(x - 0.06, y, 0.12, h);
      ctx.save();
      ctx.translate(x + 0.06, y + h);
      draw();
      ctx.restore();
    };
    pole(tr.start - 2.5, 3, () => {
      ctx.fillStyle = '#30a46c';
      ctx.fillRect(0, -0.7, 1.3, 0.7);
    });
    if (tr.finish !== null) {
      pole(tr.finish, 4.2, () => {
        const wave = Math.sin(t * 4) * 0.08;
        for (let i = 0; i < 6; i++) {
          for (let j = 0; j < 4; j++) {
            ctx.fillStyle = (i + j) % 2 ? '#1d232b' : '#ffffff';
            ctx.fillRect(i * 0.28, -0.28 * (j + 1) + wave * (i / 6), 0.28, 0.28);
          }
        }
      });
    }
  }

  function drawVehicle(ctx, v, t) {
    const S = C.CELL;
    // suspension struts
    ctx.strokeStyle = '#5b616b';
    ctx.lineWidth = 0.09;
    for (const w of v.wheels) {
      if (!w.joint) continue;
      const a = w.attach.body.getWorldPoint(V(w.attach.lx, w.attach.ly));
      const b = w.body.getPosition();
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
    const fuel = v.fuelMax ? v.fuel / v.fuelMax : 0;
    for (const b of v.blocks) {
      if (!b.alive) continue;
      ctx.save();
      body(ctx, b.body);
      ctx.translate(b.lx, b.ly);
      ctx.scale(S, S);
      const attached = b.body === v.main;
      SW.Draw.part(ctx, b.part, b.rot, {
        damage: 1 - b.hp / b.max,
        t,
        run: attached && b.part === 'engine' ? v.throttle || 0.2 : 0,
        boost: attached && v.boosting && b.part === 'booster',
        fuel,
      });
      ctx.restore();
    }
    for (const w of v.wheels) {
      ctx.save();
      const p = w.body.getPosition();
      ctx.translate(p.x, p.y);
      ctx.scale(S, S);
      SW.Draw.wheel(ctx, w.part, w.body.getAngle());
      ctx.restore();
    }
  }

  function drawCrate(ctx, crate) {
    ctx.save();
    body(ctx, crate.body);
    const { w, h } = crate;
    ctx.fillStyle = '#c99556';
    ctx.fillRect(-w / 2, -h / 2, w, h);
    ctx.strokeStyle = '#7d5530';
    ctx.lineWidth = 0.06;
    ctx.strokeRect(-w / 2, -h / 2, w, h);
    ctx.beginPath();
    ctx.moveTo(-w / 2, -h / 2);
    ctx.lineTo(w / 2, h / 2);
    ctx.moveTo(w / 2, -h / 2);
    ctx.lineTo(-w / 2, h / 2);
    ctx.stroke();
    ctx.restore();
  }

  return { draw, scaleFor };
})();
