/*
 * How every part looks. Shared by the builder and the drive, so a part always looks the same.
 *
 * Drawing happens in "cell units": one cell spans -0.5..0.5 on both axes, y points up.
 * The caller sets up the canvas transform (see SW.Render and SW.Garage).
 *   SW.Draw.part(ctx, part, rot, opts)     a block; opts: { damage 0..1, t, run, boost, fuel }
 *   SW.Draw.wheel(ctx, part, angle, opts)  a wheel centred on the origin
 */
'use strict';

SW.Draw = (() => {
  const C = SW.CFG;

  function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  function boxFill(ctx, fill, edge) {
    rr(ctx, -0.48, -0.48, 0.96, 0.96, 0.08);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.lineWidth = 0.06;
    ctx.strokeStyle = edge;
    ctx.stroke();
  }

  function rivets(ctx) {
    ctx.fillStyle = 'rgba(40,46,54,0.55)';
    for (const x of [-0.33, 0.33]) {
      for (const y of [-0.33, 0.33]) {
        ctx.beginPath();
        ctx.arc(x, y, 0.055, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  function cracks(ctx, damage) {
    if (damage < 0.35) return;
    ctx.strokeStyle = 'rgba(30,20,10,0.75)';
    ctx.lineWidth = 0.05;
    ctx.beginPath();
    ctx.moveTo(-0.3, 0.42);
    ctx.lineTo(-0.05, 0.1);
    ctx.lineTo(-0.15, -0.1);
    if (damage > 0.65) {
      ctx.moveTo(0.4, -0.2);
      ctx.lineTo(0.1, 0);
      ctx.lineTo(0.2, 0.3);
      ctx.moveTo(-0.05, 0.1);
      ctx.lineTo(0.15, -0.35);
    }
    ctx.stroke();
  }

  const DRAW = {
    wood(ctx) {
      boxFill(ctx, '#c08a55', '#7d5530');
      ctx.strokeStyle = 'rgba(110,70,35,0.45)';
      ctx.lineWidth = 0.035;
      ctx.beginPath();
      for (const y of [-0.22, 0.02, 0.24]) {
        ctx.moveTo(-0.4, y);
        ctx.bezierCurveTo(-0.15, y + 0.06, 0.1, y - 0.05, 0.4, y + 0.02);
      }
      ctx.stroke();
    },
    steel(ctx) {
      const g = ctx.createLinearGradient(-0.5, 0.5, 0.5, -0.5);
      g.addColorStop(0, '#aab4bf');
      g.addColorStop(1, '#6f7a86');
      boxFill(ctx, g, '#4b545e');
      rivets(ctx);
    },
    rubber(ctx) {
      boxFill(ctx, '#33363d', '#1c1e22');
      ctx.fillStyle = '#4a4e57';
      rr(ctx, -0.36, -0.1, 0.72, 0.2, 0.08);
      ctx.fill();
    },
    bed(ctx) {
      boxFill(ctx, '#8f6a45', '#5e4228');
      ctx.fillStyle = '#e9b33a';
      ctx.fillRect(-0.48, 0.28, 0.96, 0.2);
      ctx.fillStyle = '#2b2f36';
      for (let x = -0.44; x < 0.44; x += 0.24) {
        ctx.beginPath();
        ctx.moveTo(x, 0.28);
        ctx.lineTo(x + 0.12, 0.28);
        ctx.lineTo(x + 0.2, 0.48);
        ctx.lineTo(x + 0.08, 0.48);
        ctx.fill();
      }
    },
    seat(ctx) {
      boxFill(ctx, '#dfe3e8', '#8a929c');
      // seat
      ctx.fillStyle = '#c0392b';
      rr(ctx, -0.36, -0.36, 0.5, 0.16, 0.05);
      ctx.fill();
      rr(ctx, -0.38, -0.36, 0.14, 0.62, 0.05);
      ctx.fill();
      // driver
      ctx.fillStyle = '#2f6fd6';
      rr(ctx, -0.2, -0.22, 0.32, 0.5, 0.1);
      ctx.fill();
      ctx.strokeStyle = '#2f6fd6';
      ctx.lineWidth = 0.1;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(0.05, 0.12);
      ctx.lineTo(0.34, 0.02);
      ctx.stroke();
      // head and helmet (pokes out above the cell: this is the part that must not touch the ground)
      ctx.fillStyle = '#f1c7a3';
      ctx.beginPath();
      ctx.arc(-0.04, 0.64, 0.24, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#f2a516';
      ctx.beginPath();
      ctx.arc(-0.04, 0.68, 0.27, 0, Math.PI);
      ctx.fill();
      ctx.fillStyle = '#1d232b';
      ctx.fillRect(0.06, 0.62, 0.14, 0.06);
    },
    engine(ctx, o) {
      const j = o.run ? Math.sin(o.t * 70) * 0.02 * (0.3 + Math.abs(o.run)) : 0;
      ctx.translate(0, j);
      boxFill(ctx, '#3d4148', '#22252a');
      ctx.fillStyle = '#5b616b';
      for (let i = 0; i < 4; i++) ctx.fillRect(-0.34 + i * 0.18, -0.05, 0.1, 0.4);
      ctx.fillStyle = '#e5484d';
      rr(ctx, -0.36, -0.36, 0.72, 0.22, 0.05);
      ctx.fill();
      ctx.fillStyle = '#9aa1a8';
      ctx.fillRect(0.3, 0.3, 0.16, 0.12);
    },
    tank(ctx, o) {
      boxFill(ctx, '#d9472b', '#8c2a18');
      ctx.fillStyle = 'rgba(255,255,255,0.22)';
      rr(ctx, -0.36, 0.05, 0.16, 0.3, 0.05);
      ctx.fill();
      ctx.fillStyle = '#2b2f36';
      ctx.fillRect(0.12, 0.3, 0.2, 0.14);
      const level = o.fuel === undefined ? 1 : o.fuel;
      ctx.fillStyle = 'rgba(0,0,0,0.35)';
      ctx.fillRect(-0.1, -0.36, 0.42, 0.12);
      ctx.fillStyle = '#ffd34d';
      ctx.fillRect(-0.1, -0.36, 0.42 * level, 0.12);
    },
    gyro(ctx, o) {
      boxFill(ctx, '#2b3a55', '#141c2b');
      ctx.save();
      ctx.rotate((o.t || 0) * 6);
      ctx.strokeStyle = '#6ec1ff';
      ctx.lineWidth = 0.07;
      ctx.beginPath();
      ctx.ellipse(0, 0, 0.33, 0.14, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
      ctx.fillStyle = '#cfe9ff';
      ctx.beginPath();
      ctx.arc(0, 0, 0.1, 0, Math.PI * 2);
      ctx.fill();
    },
    wedge(ctx) {
      ctx.beginPath();
      ctx.moveTo(-0.48, -0.48);
      ctx.lineTo(0.48, -0.48);
      ctx.lineTo(-0.48, 0.48);
      ctx.closePath();
      ctx.fillStyle = '#c08a55';
      ctx.fill();
      ctx.lineWidth = 0.06;
      ctx.strokeStyle = '#7d5530';
      ctx.stroke();
    },
    booster(ctx, o) {
      // drawn pointing forward (+x); the nozzle is at the back (-x)
      ctx.fillStyle = '#c9ced6';
      rr(ctx, -0.2, -0.3, 0.66, 0.6, 0.2);
      ctx.fill();
      ctx.strokeStyle = '#6f7a86';
      ctx.lineWidth = 0.05;
      ctx.stroke();
      ctx.fillStyle = '#e5484d';
      ctx.beginPath();
      ctx.moveTo(0.46, -0.3);
      ctx.quadraticCurveTo(0.62, 0, 0.46, 0.3);
      ctx.fill();
      ctx.fillStyle = '#4b545e';
      ctx.beginPath();
      ctx.moveTo(-0.2, -0.22);
      ctx.lineTo(-0.48, -0.32);
      ctx.lineTo(-0.48, 0.32);
      ctx.lineTo(-0.2, 0.22);
      ctx.fill();
      if (o.boost) {
        const f = 0.5 + Math.random() * 0.5;
        const g = ctx.createLinearGradient(-0.5, 0, -1.6, 0);
        g.addColorStop(0, '#fff3b0');
        g.addColorStop(0.4, '#ffa62b');
        g.addColorStop(1, 'rgba(229,72,77,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(-0.48, -0.26);
        ctx.lineTo(-0.5 - 1.1 * f, 0);
        ctx.lineTo(-0.48, 0.26);
        ctx.fill();
      }
    },
  };

  function part(ctx, name, rot, o = {}) {
    ctx.save();
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    if (rot) ctx.rotate((-rot * Math.PI) / 2);
    (DRAW[name] || DRAW.wood)(ctx, o);
    if (o.damage) cracks(ctx, o.damage);
    if (o.tint) {
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = o.tint;
      ctx.fillRect(-0.6, -0.6, 1.2, 1.2);
    }
    ctx.restore();
  }

  function wheel(ctx, name, angle, o = {}) {
    const r = C.PARTS[name].radius / C.CELL;
    ctx.save();
    if (o.alpha !== undefined) ctx.globalAlpha *= o.alpha;
    ctx.rotate(angle || 0);
    ctx.fillStyle = '#23262b';
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.fill();
    if (name === 'grip') {
      ctx.fillStyle = '#23262b';
      for (let i = 0; i < 12; i++) {
        ctx.save();
        ctx.rotate((i / 12) * Math.PI * 2);
        ctx.fillRect(r - 0.05, -0.07, 0.14, 0.14);
        ctx.restore();
      }
    }
    ctx.fillStyle = name === 'bigwheel' ? '#e5b64a' : name === 'grip' ? '#e5484d' : '#b9c0c8';
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.58, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#3d4148';
    ctx.lineWidth = 0.07;
    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(a) * r * 0.55, Math.sin(a) * r * 0.55);
    }
    ctx.stroke();
    ctx.fillStyle = '#3d4148';
    ctx.beginPath();
    ctx.arc(0, 0, r * 0.15, 0, Math.PI * 2);
    ctx.fill();
    if (o.tint) {
      ctx.globalCompositeOperation = 'source-atop';
      ctx.fillStyle = o.tint;
      ctx.fillRect(-r, -r, 2 * r, 2 * r);
    }
    ctx.restore();
  }

  // A small icon of a part for buttons (drawn into its own canvas).
  function icon(name, size) {
    const c = document.createElement('canvas');
    c.width = c.height = size * 2;
    const ctx = c.getContext('2d');
    const P = C.PARTS[name];
    const scale = P.kind === 'wheel' ? (size * 2 * 0.45) / (P.radius / C.CELL) : size * 1.3;
    ctx.translate(size, size * (name === 'seat' ? 1.15 : 1));
    ctx.scale(scale, -scale);
    if (P.kind === 'wheel') wheel(ctx, name, 0.4);
    else part(ctx, name, 0, { t: 0 });
    return c;
  }

  return { part, wheel, icon, rr };
})();
