/*
 * Particles in world space: dust from spinning wheels, engine smoke, booster flames,
 * sparks on hard hits, splinters when a block breaks, and sparkles on pickups.
 */
'use strict';

SW.Effects = (() => {
  const MAX = 600;
  let list = [];

  const reset = () => (list = []);
  const enabled = () => SW.Save.settings().particles;

  function add(p) {
    if (list.length >= MAX) list.shift();
    list.push(Object.assign({ age: 0, grow: 0, drag: 1.5, gravity: 0 }, p));
  }

  function impact(x, y, strength) {
    if (!enabled()) return;
    const n = Math.min(10, Math.floor(strength / 6));
    for (let i = 0; i < n; i++) {
      add({
        x,
        y,
        vx: (Math.random() - 0.5) * 6,
        vy: Math.random() * 4,
        life: 0.3 + Math.random() * 0.3,
        size: 0.06,
        color: '#ffd27a',
        gravity: -12,
      });
    }
  }

  const CHIPS = {
    wood: '#c08a55',
    wedge: '#c08a55',
    bed: '#8f6a45',
    steel: '#9aa4af',
    rubber: '#33363d',
    seat: '#dfe3e8',
    engine: '#3d4148',
    tank: '#d9472b',
    gyro: '#2b3a55',
    booster: '#c9ced6',
  };

  function shatter(x, y, part) {
    for (let i = 0; i < 14; i++) {
      add({
        x: x + (Math.random() - 0.5) * 0.4,
        y: y + (Math.random() - 0.5) * 0.4,
        vx: (Math.random() - 0.5) * 7,
        vy: Math.random() * 6,
        life: 0.6 + Math.random() * 0.6,
        size: 0.08 + Math.random() * 0.08,
        color: CHIPS[part] || '#888',
        gravity: -14,
        drag: 0.5,
        square: true,
      });
    }
    for (let i = 0; i < 6; i++) smoke(x, y, 0.5, '#9a9a9a');
  }

  function smoke(x, y, size, color) {
    add({
      x,
      y,
      vx: (Math.random() - 0.5) * 0.8,
      vy: 0.6 + Math.random() * 0.6,
      life: 0.8 + Math.random() * 0.6,
      size: size * 0.4,
      grow: size,
      color,
      alpha: 0.35,
    });
  }

  function sparkle(x, y, color) {
    if (!enabled()) return;
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      add({ x, y, vx: Math.cos(a) * 3, vy: Math.sin(a) * 3, life: 0.4, size: 0.07, color, drag: 4 });
    }
  }

  let timer = 0;
  // Per-step effects coming from the vehicle: exhaust, wheel dust, booster flames.
  function vehicle(v, state, dt) {
    if (!enabled()) return;
    timer += dt;
    if (timer < 1 / 30) return;
    timer = 0;
    const body = v.main;
    const V = SW.World.V;
    if (v.throttle) {
      for (const b of v.blocks) {
        if (b.part !== 'engine' || !b.alive || b.body !== body) continue;
        const p = body.getWorldPoint(V(b.lx + 0.2, b.ly + 0.25));
        if (Math.random() < 0.35) smoke(p.x, p.y, 0.22, '#6b6f75');
      }
      for (const w of v.stats.drive) {
        if (!touching(w.body)) continue;
        const p = w.body.getPosition();
        const spin = Math.abs(w.body.getAngularVelocity() * w.radius - body.getLinearVelocity().x);
        if (spin > 2.5 || Math.random() < 0.04) {
          add({
            x: p.x - Math.sign(v.throttle) * w.radius * 0.8,
            y: p.y - w.radius * 0.9,
            vx: -Math.sign(v.throttle) * (1 + Math.random() * 2),
            vy: 0.5 + Math.random() * 1.5,
            life: 0.35 + Math.random() * 0.3,
            size: 0.07,
            grow: 0.28,
            color: state.theme === 'moon' ? '#c9ccd6' : '#a98a63',
            alpha: 0.3,
            gravity: -2,
          });
        }
      }
    }
    if (v.boosting) {
      for (const b of v.stats.boosters) {
        const [dx, dy] = SW.Vehicle.thrustDir(b.rot);
        const back = body.getWorldVector(V(-dx, -dy));
        const p = body.getWorldPoint(V(b.lx - dx * 0.35, b.ly - dy * 0.35));
        add({
          x: p.x,
          y: p.y,
          vx: back.x * 9 + (Math.random() - 0.5),
          vy: back.y * 9 + (Math.random() - 0.5),
          life: 0.22,
          size: 0.1,
          grow: 0.22,
          color: Math.random() < 0.5 ? '#ffb347' : '#ff6a3d',
          alpha: 0.8,
          drag: 3,
        });
        if (Math.random() < 0.25) smoke(p.x + back.x * 0.8, p.y + back.y * 0.8, 0.3, '#8a8a8a');
      }
    }
  }

  function touching(body) {
    for (let e = body.getContactList(); e; e = e.next) {
      if (e.contact.isTouching()) {
        const other = e.other.getFixtureList();
        const ud = other && other.getUserData();
        if (ud && ['ground', 'rock', 'plank'].includes(ud.type)) return true;
      }
    }
    return false;
  }

  function update(dt) {
    for (const p of list) {
      p.age += dt;
      p.vx -= p.vx * Math.min(1, p.drag * dt);
      p.vy -= p.vy * Math.min(1, p.drag * dt) - p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
    }
    list = list.filter(p => p.age < p.life);
  }

  // ctx must already be in world space (metres, y up).
  function draw(ctx) {
    for (const p of list) {
      const t = p.age / p.life;
      const size = p.size + p.grow * t;
      ctx.globalAlpha = (p.alpha || 1) * (1 - t);
      ctx.fillStyle = p.color;
      if (p.square) ctx.fillRect(p.x - size / 2, p.y - size / 2, size, size);
      else {
        ctx.beginPath();
        ctx.arc(p.x, p.y, size, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.globalAlpha = 1;
  }

  return { reset, impact, shatter, sparkle, vehicle, update, draw, touching };
})();
